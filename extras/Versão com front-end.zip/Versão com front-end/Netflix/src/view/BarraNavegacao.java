package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Barra do topo, igual em todas as telas: a marca NETFLIX e um botao para cada tela
 * (Inicio, Planos, Contas, Perfis, Titulos e Historico). O botao da tela
 * onde o usuario esta fica em destaque (branco e negrito) e nao faz nada.
 *
 * Cada botao troca de tela pelo Navegador (a tela nova abre no mesmo lugar da atual).
 * Esta classe so monta a interface: nao tem SQL nem regra de negocio.
 */
public class BarraNavegacao extends JPanel {

    /**
     * @param dona    a janela onde a barra esta (ela sera trocada pela tela escolhida)
     * @param atual   nome da tela atual, igual ao texto do botao ("Início", "Planos"...)
     * @param direita componente opcional no canto direito (ex.: botao "Restaurar dados"); pode ser null
     */
    public BarraNavegacao(JFrame dona, String atual, Component direita) {
        super(new BorderLayout());
        setBackground(new Color(0x0e0e0e));
        setBorder(BorderFactory.createEmptyBorder(8, 28, 8, 20));

        JPanel esquerda = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        esquerda.setOpaque(false);
        JLabel marca = new JLabel("NETFLIX");
        marca.setFont(Tema.FONTE_TITULO.deriveFont(Font.BOLD, 28f));
        marca.setForeground(Tema.VERMELHO);
        marca.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 18));
        esquerda.add(marca);

        esquerda.add(item("Início", atual, e -> Navegador.ir(dona, new TelaPrincipal())));
        esquerda.add(item("Planos", atual, e -> Navegador.ir(dona, new TelaPlano())));
        esquerda.add(item("Contas", atual, e -> Navegador.ir(dona, new TelaConta())));
        esquerda.add(item("Perfis", atual, e -> Navegador.ir(dona, new TelaPerfil())));
        esquerda.add(item("Títulos", atual, e -> Navegador.ir(dona, new TelaTitulo())));
        esquerda.add(item("Histórico", atual, e -> Navegador.ir(dona, new TelaHistorico())));
        add(esquerda, BorderLayout.WEST);

        if (direita != null) {
            JPanel painelDireita = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
            painelDireita.setOpaque(false);
            painelDireita.add(direita);
            add(painelDireita, BorderLayout.EAST);
        }
    }

    private ItemDoMenu item(String texto, String atual, ActionListener acao) {
        ItemDoMenu b = new ItemDoMenu(texto, texto.equals(atual));
        if (!texto.equals(atual)) {
            b.addActionListener(acao); // o botao da tela atual nao faz nada
        }
        return b;
    }

    /** Botao so de texto: cinza, branco ao passar o mouse, negrito se for a tela atual. */
    public static final class ItemDoMenu extends JButton {
        private final boolean atual;

        public ItemDoMenu(String texto, boolean atual) {
            super(texto);
            this.atual = atual;
            setFont(atual ? Tema.FONTE_NEGRITO.deriveFont(14f) : Tema.FONTE.deriveFont(14f));
            setForeground(atual ? Color.WHITE : new Color(0xb3b3b3));
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setRolloverEnabled(true);
            setCursor(atual ? Cursor.getDefaultCursor() : Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        }

        @Override
        protected void paintComponent(Graphics g) {
            setForeground(atual || getModel().isRollover() || isFocusOwner() ? Color.WHITE : new Color(0xb3b3b3));
            super.paintComponent(g);
            if (isFocusOwner()) { // sublinhado branco = foco do teclado
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(Color.WHITE);
                g2.fillRect(10, getHeight() - 5, getWidth() - 20, 2);
                g2.dispose();
            }
        }
    }
}
