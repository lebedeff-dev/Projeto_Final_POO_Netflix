package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import controller.RelatorioController;
import model.HistoricoVisualizacao;
import util.Conversor;

/**
 * RELATORIO da rotina principal: visualizacoes por periodo (e por perfil).
 *
 * Nao herda de TelaCrud porque nao e um cadastro: so tem filtros, uma tabela
 * (resultado do INNER JOIN) e os totais calculados pelo Controller.
 */
public class TelaRelatorio extends JFrame {

    private final RelatorioController controller = new RelatorioController();

    private final JTextField campoDataInicial = new JTextField("01/01/2025", 10);
    private final JTextField campoDataFinal = new JTextField(Conversor.hoje(), 10);
    private final JComboBox<String> comboPerfil = new JComboBox<>();
    private final JPanel faixaResumo = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
    private final DefaultTableModel modelo = new DefaultTableModel(
            new String[]{"ID", "Início", "Perfil", "Conta", "Plano", "Título", "Minuto de parada", "Concluído", "Dispositivo"}, 0) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    };

    // Ultimo resultado gerado (usado pelo botao "Salvar .txt").
    private final JTable tabelaRelatorio = new JTable(modelo);

    private List<HistoricoVisualizacao> resultado = new ArrayList<>();

    // Filtros que foram USADOS para gerar o 'resultado' acima. O "Salvar .txt" usa estes valores e nao o
    // que estiver digitado nos campos agora, senao o arquivo teria linhas de um periodo e cabecalho de outro.
    private String filtroDataInicial = "";
    private String filtroDataFinal = "";
    private String filtroPerfil = RelatorioController.TODOS;

    public TelaRelatorio() {
        super("Relatório - Visualizações por período");

        JButton btnGerar = new Tema.Botao("Gerar relatório", Tema.TipoBotao.PRINCIPAL);
        JButton btnSalvar = new Tema.Botao("Salvar .txt", Tema.TipoBotao.SECUNDARIO);
        btnGerar.addActionListener(e -> gerar());
        btnSalvar.addActionListener(e -> salvar());

        Tema.estilizarCampo(campoDataInicial);
        Tema.estilizarCampo(campoDataFinal);
        Tema.estilizarCombo(comboPerfil);

        // Filtros em uma linha: cada um com o rotulo pequeno em cima; os botoes no fim.
        JPanel painelFiltros = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        painelFiltros.setOpaque(false);
        painelFiltros.setBorder(BorderFactory.createEmptyBorder(18, 24, 14, 24));
        painelFiltros.add(celula("Data inicial (dd/mm/aaaa)", campoDataInicial));
        painelFiltros.add(celula("Data final", campoDataFinal));
        comboPerfil.setPreferredSize(new java.awt.Dimension(220, 38));
        painelFiltros.add(celula("Perfil", comboPerfil));
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        botoes.setOpaque(false);
        botoes.add(btnGerar);
        botoes.add(btnSalvar);
        JPanel botoesAlinhados = new JPanel(new BorderLayout());   // desce os botoes para a altura dos campos
        botoesAlinhados.setOpaque(false);
        botoesAlinhados.setBorder(BorderFactory.createEmptyBorder(18, 0, 0, 0));
        botoesAlinhados.add(botoes, BorderLayout.CENTER);
        painelFiltros.add(botoesAlinhados);

        // Totais embaixo: um "chip" para cada total (total, concluidas, em andamento, minutos)
        faixaResumo.setBackground(Tema.PAINEL);
        faixaResumo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Tema.BORDA),
                BorderFactory.createEmptyBorder(14, 24, 14, 24)));

        Tema.estilizarTabela(tabelaRelatorio);
        JPanel areaTabela = new JPanel(new BorderLayout());
        areaTabela.setOpaque(false);
        areaTabela.setBorder(BorderFactory.createEmptyBorder(0, 24, 18, 24));
        areaTabela.add(Tema.rolagem(tabelaRelatorio), BorderLayout.CENTER);

        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        JPanel barraECabecalho = new JPanel(new BorderLayout());
        barraECabecalho.setOpaque(false);
        barraECabecalho.add(new BarraNavegacao(this, "Relatório", null), BorderLayout.NORTH);
        barraECabecalho.add(Tema.cabecalho("Relatório de visualizações", "Visualizações iniciadas no período escolhido, com totais."), BorderLayout.CENTER);
        topo.add(barraECabecalho, BorderLayout.NORTH);
        topo.add(painelFiltros, BorderLayout.CENTER);

        Tema.fundoDaJanela(this);
        add(topo, BorderLayout.NORTH);
        add(areaTabela, BorderLayout.CENTER);
        add(faixaResumo, BorderLayout.SOUTH);

        java.awt.Dimension tela = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setSize(Math.min(1160, tela.width - 60), Math.min(640, tela.height - 80));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        try {
            for (String opcao : controller.opcoesPerfis()) {
                comboPerfil.addItem(opcao);
            }
            gerar(); // ja abre mostrando o relatorio do periodo padrao
        } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Rotulo pequeno em cima e o campo embaixo. */
    private JPanel celula(String rotulo, javax.swing.JComponent campo) {
        JPanel p = new JPanel(new BorderLayout(0, 5));
        p.setOpaque(false);
        p.add(Tema.rotulo(rotulo), BorderLayout.NORTH);
        p.add(campo, BorderLayout.CENTER);
        return p;
    }

    /**
     * O Controller devolve os totais em uma linha ("Total de visualizacoes: 6   |   Concluidas: 3 ...").
     * Aqui so FORMATAMOS esse texto: cada parte vira um chip com o rotulo pequeno e o numero grande.
     */
    private void mostrarTotais(String resumo) {
        faixaResumo.removeAll();
        for (String parte : resumo.split("\\|")) {
            String[] rotuloEValor = parte.trim().split(":");
            if (rotuloEValor.length == 2) {
                faixaResumo.add(Tema.chip(rotuloEValor[0].trim(), rotuloEValor[1].trim()));
            }
        }
        faixaResumo.revalidate();
        faixaResumo.repaint();
    }

    /** Pede o relatorio ao Controller e mostra as linhas e os totais. */
    private void gerar() {
        try {
            resultado = controller.gerar(campoDataInicial.getText(), campoDataFinal.getText(),
                    (String) comboPerfil.getSelectedItem());
        } catch (RuntimeException e) { // validacao (datas) ou erro de banco
            JOptionPane.showMessageDialog(this, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        filtroDataInicial = campoDataInicial.getText();
        filtroDataFinal = campoDataFinal.getText();
        filtroPerfil = (String) comboPerfil.getSelectedItem();

        modelo.setRowCount(0);
        for (HistoricoVisualizacao h : resultado) {
            modelo.addRow(new Object[]{h.getIdVisualizacao(), Conversor.formatarDataHora(h.getDataInicio()),
                    h.getNomePerfil(), h.getEmailConta(), h.getNomePlano(), h.getNomeTitulo(), h.getMinutoParada(),
                    Conversor.simNao(h.isConcluido()), h.getDispositivo()});
        }
        mostrarTotais(controller.resumo(resultado));
        Tema.ajustarColunas(tabelaRelatorio);
    }

    /** Abre a janela "Salvar como" e pede ao Controller para gravar o .txt. */
    private void salvar() {
        JFileChooser escolher = new JFileChooser();
        escolher.setSelectedFile(new File("relatorio_visualizacoes.txt"));
        if (escolher.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            String mensagem = controller.salvarTxt(escolher.getSelectedFile().getAbsolutePath(), resultado,
                    filtroDataInicial, filtroDataFinal, filtroPerfil);
            JOptionPane.showMessageDialog(this, mensagem);
        }
    }
}
