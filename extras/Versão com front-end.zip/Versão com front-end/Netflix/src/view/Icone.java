package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Path2D;

/**
 * Icones do menu, DESENHADOS EM CODIGO (nenhuma imagem externa).
 *
 * Cada icone e feito de linhas e formas simples numa grade de 24 x 24. O metodo desenhar()
 * escala essa grade para o tamanho pedido, entao o mesmo icone serve para tamanho pequeno
 * (barra lateral) e grande (cartoes), sem perder qualidade.
 */
public enum Icone {
    CASA, PLANOS, CONTAS;

    /** Desenha o icone com o canto superior esquerdo em (x, y), com lado 'tamanho' e a cor dada. */
    public void desenhar(Graphics2D g, int x, int y, int tamanho, Color cor) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g2.translate(x, y);
        g2.scale(tamanho / 24.0, tamanho / 24.0);
        g2.setColor(cor);
        g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        switch (this) {
            case CASA: { // telhado + paredes + porta
                Path2D telhado = new Path2D.Float();
                telhado.moveTo(3, 11);
                telhado.lineTo(12, 3);
                telhado.lineTo(21, 11);
                g2.draw(telhado);
                Path2D paredes = new Path2D.Float();
                paredes.moveTo(5, 10);
                paredes.lineTo(5, 20);
                paredes.lineTo(19, 20);
                paredes.lineTo(19, 10);
                g2.draw(paredes);
                g2.drawRect(10, 14, 4, 6);
                break;
            }
            case PLANOS: // cartao (assinatura)
                g2.drawRoundRect(2, 5, 20, 14, 4, 4);
                g2.drawLine(2, 10, 22, 10);
                g2.drawLine(5, 15, 10, 15);
                break;
            case CONTAS: { // envelope (o e-mail identifica a conta)
                g2.drawRoundRect(2, 5, 20, 14, 4, 4);
                Path2D aba = new Path2D.Float();
                aba.moveTo(3, 7);
                aba.lineTo(12, 14);
                aba.lineTo(21, 7);
                g2.draw(aba);
                break;
            }
        }
        g2.dispose();
    }
}
