package view;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.table.DefaultTableModel;

/**
 * As quatro VISOES visuais do sistema, inspiradas no app da Netflix. Todas leem o DefaultTableModel da
 * tela (os mesmos dados da tabela) e desenham com Java2D (Graphics2D), sem nenhuma imagem:
 *
 *  - Perfis    : avatares coloridos com carinha, como na tela "Quem esta assistindo?";
 *  - Contas    : cartoes com etiqueta de status, como em "Gerenciar acesso e aparelhos";
 *  - Historico : lista "O que foi assistido", com miniatura, data e botao X para remover;
 *  - Planos    : tabela comparativa de planos, como em "Escolha o melhor plano".
 *
 * Clicar num desenho seleciona o registro (a tela preenche o formulario para editar).
 * Esta classe e so de aparencia: nao tem SQL, regra de negocio nem chamada ao Controller.
 */
public final class Visoes {

    private Visoes() {
    }

    // ---------- cores e utilitarios compartilhados ----------


    private static Graphics2D preparar(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        return g2;
    }

    /** Corta o texto com "..." para caber na largura dada. */
    private static String cortar(String texto, FontMetrics fm, int largura) {
        if (fm.stringWidth(texto) <= largura) {
            return texto;
        }
        String cortado = texto;
        while (cortado.length() > 1 && fm.stringWidth(cortado + "…") > largura) {
            cortado = cortado.substring(0, cortado.length() - 1);
        }
        return cortado + "…";
    }

    /** Divide o texto em linhas que cabem na largura (para o nome do titulo dentro da miniatura). */
    private static List<String> quebrar(String texto, FontMetrics fm, int largura, int maximoDeLinhas) {
        List<String> linhas = new ArrayList<>();
        String atual = "";
        for (String palavra : texto.split(" ")) {
            String tentativa = atual.isEmpty() ? palavra : atual + " " + palavra;
            if (fm.stringWidth(tentativa) <= largura || atual.isEmpty()) {
                atual = tentativa;
            } else {
                linhas.add(atual);
                atual = palavra;
            }
        }
        if (!atual.isEmpty()) {
            linhas.add(atual);
        }
        while (linhas.size() > maximoDeLinhas) {
            linhas.remove(linhas.size() - 1);
        }
        return linhas;
    }

    private static void textoCentralizado(Graphics2D g, String texto, int centroX, int baseY) {
        g.drawString(texto, centroX - g.getFontMetrics().stringWidth(texto) / 2, baseY);
    }

    // =====================================================================================
    // Base dos desenhos clicaveis
    // =====================================================================================

    /** Um desenho clicavel que representa UMA linha do modelo: tem hover, selecao e foco do teclado. */
    private abstract static class Item extends JComponent {
        protected final int linha;
        protected final Visao.Acoes acoes;
        protected boolean selecionado;
        protected boolean sobre;

        Item(int linha, Visao.Acoes acoes) {
            this.linha = linha;
            this.acoes = acoes;
            setFocusable(true);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    sobre = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    sobre = false;
                    aoSair();
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    requestFocusInWindow();
                    aoClicar(e.getX(), e.getY());
                }
            });
            addKeyListener(new KeyAdapter() { // Enter ou espaco escolhem o item (acessibilidade)
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_ENTER || e.getKeyCode() == KeyEvent.VK_SPACE) {
                        acoes.selecionar(Item.this.linha);
                    }
                }
            });
            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    repaint();
                }

                @Override
                public void focusLost(FocusEvent e) {
                    repaint();
                }
            });
        }

        protected void aoClicar(int x, int y) {
            acoes.selecionar(linha);
        }

        protected void aoSair() {
        }

        void definirSelecionado(boolean valor) {
            selecionado = valor;
            repaint();
        }

        /** Contorno de selecao (vermelho) ou de foco do teclado (branco). */
        protected void contorno(Graphics2D g, int w, int h, int arco) {
            if (selecionado || isFocusOwner()) {
                g.setColor(selecionado ? Tema.VERMELHO : Color.WHITE);
                g.setStroke(new BasicStroke(selecionado ? 2.5f : 2f));
                g.drawRoundRect(1, 1, w - 3, h - 3, arco, arco);
            }
        }
    }

    // =====================================================================================
    // PERFIS: avatares com carinha
    // =====================================================================================

    public static final class Perfis extends Visao {
        // Cores dos avatares (do app: azul, amarelo, vermelho e azul-petroleo); [0] = topo, [1] = base do degrade
        private static final Color[][] AVATARES = {
            {new Color(0x1a73e8), new Color(0x66a6f2)},
            {new Color(0xe3a500), new Color(0xf2d070)},
            {new Color(0xe50914), new Color(0xf0707a)},
            {new Color(0x0e3a4a), new Color(0x6d98a6)}};

        private final PainelRolavel lista = new PainelRolavel(new PainelRolavel.QuebraLayout(FlowLayout.LEFT, 22, 22));
        private final List<Avatar> avatares = new ArrayList<>();

        public Perfis(DefaultTableModel modelo, Acoes acoes) {
            super(modelo, acoes);
            setLayout(new BorderLayout());
            lista.setBorder(javax.swing.BorderFactory.createEmptyBorder(14, 6, 14, 6));
            add(Tema.rolagemSimples(lista), BorderLayout.CENTER);
        }

        @Override
        public void atualizar() {
            lista.removeAll();
            avatares.clear();
            // colunas do modelo: 0 ID, 1 Conta, 2 Nome, 3 Avatar, 4 Perfil infantil, 5 PIN
            for (int l = 0; l < modelo.getRowCount(); l++) {
                Avatar a = new Avatar(l, acoes, texto(l, 2), semId(l, 1), "Sim".equals(texto(l, 4)),
                        AVATARES[Math.abs(texto(l, 0).hashCode()) % AVATARES.length], false);
                avatares.add(a);
                lista.add(a);
            }
            lista.add(new Avatar(-1, acoes, "Novo perfil", "Cadastrar", false, AVATARES[0], true));
            lista.revalidate();
            lista.repaint();
        }

        @Override
        public void marcar(int linha) {
            for (Avatar a : avatares) {
                a.definirSelecionado(a.linha == linha);
            }
        }

        /** Um avatar: quadrado colorido com carinha (ou "KiDS" no perfil infantil) e o nome embaixo. */
        private static final class Avatar extends Item {
            private final String nome;
            private final String legenda;
            private final boolean infantil;
            private final Color[] cores;
            private final boolean botaoNovo;

            Avatar(int linha, Acoes acoes, String nome, String legenda, boolean infantil, Color[] cores, boolean botaoNovo) {
                super(linha, acoes);
                this.nome = nome;
                this.legenda = legenda;
                this.infantil = infantil;
                this.cores = cores;
                this.botaoNovo = botaoNovo;
                setPreferredSize(new Dimension(150, 206));
                setToolTipText(nome);
            }

            @Override
            protected void aoClicar(int x, int y) {
                if (botaoNovo) {
                    acoes.novo();
                } else {
                    acoes.selecionar(linha);
                }
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = preparar(g);
                int lado = 124, x = (getWidth() - lado) / 2, y = 8;
                boolean destaque = selecionado || sobre || isFocusOwner();

                if (botaoNovo) {                               // "+ Novo perfil": quadrado tracejado
                    g2.setColor(destaque ? Color.WHITE : Tema.BORDA);
                    g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1f, new float[]{7f, 6f}, 0f));
                    g2.drawRoundRect(x, y, lado, lado, 14, 14);
                    g2.setStroke(new BasicStroke(4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g2.drawLine(x + lado / 2 - 16, y + lado / 2, x + lado / 2 + 16, y + lado / 2);
                    g2.drawLine(x + lado / 2, y + lado / 2 - 16, x + lado / 2, y + lado / 2 + 16);
                } else if (infantil && Capa.desenharSeExistir(g2, "kids", x, y, lado, lado, 14)) {
                    // perfil infantil: usa a imagem capas/kids.png (se nao existir, cai no desenho abaixo)
                } else if (infantil) {                          // perfil infantil: quadrado claro com "KiDS"
                    g2.setPaint(new GradientPaint(x, y, new Color(0xf4f4f4), x, y + lado, new Color(0xd6d6d6)));
                    g2.fillRoundRect(x, y, lado, lado, 14, 14);
                    g2.setColor(new Color(0x303030));
                    g2.setFont(Tema.FONTE_TITULO.deriveFont(30f));
                    textoCentralizado(g2, "KiDS", getWidth() / 2, y + lado / 2 + 11);
                } else {                                        // perfil comum: degrade com carinha
                    g2.setPaint(new GradientPaint(x, y, cores[0], x, y + lado, cores[1]));
                    g2.fillRoundRect(x, y, lado, lado, 14, 14);
                    g2.setColor(Color.WHITE);
                    g2.fillOval(x + lado * 3 / 10 - 5, y + lado * 36 / 100, 10, 10);
                    g2.fillOval(x + lado * 7 / 10 - 5, y + lado * 36 / 100, 10, 10);
                    g2.setStroke(new BasicStroke(3.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g2.drawArc(x + lado * 3 / 10, y + lado * 44 / 100, lado * 4 / 10, lado * 22 / 100, 205, 130);
                }
                if (selecionado && !botaoNovo) {                // selecionado: contorno branco, como no app
                    g2.setColor(Color.WHITE);
                    g2.setStroke(new BasicStroke(3.5f));
                    g2.drawRoundRect(x - 4, y - 4, lado + 7, lado + 7, 18, 18);
                } else if (sobre && !botaoNovo) {
                    g2.setColor(new Color(255, 255, 255, 140));
                    g2.setStroke(new BasicStroke(2.5f));
                    g2.drawRoundRect(x - 3, y - 3, lado + 5, lado + 5, 17, 17);
                }

                g2.setFont(Tema.FONTE_NEGRITO.deriveFont(15f));
                g2.setColor(destaque ? Color.WHITE : Tema.TEXTO_SUAVE);
                textoCentralizado(g2, cortar(nome, g2.getFontMetrics(), getWidth() - 12), getWidth() / 2, y + lado + 28);
                g2.setFont(Tema.FONTE_PEQUENA.deriveFont(11f));
                g2.setColor(new Color(0x808080));
                textoCentralizado(g2, cortar(legenda, g2.getFontMetrics(), getWidth() - 12), getWidth() / 2, y + lado + 46);
                g2.dispose();
            }
        }
    }

    // =====================================================================================
    // CONTAS: cartoes (estilo "Gerenciar acesso e aparelhos")
    // =====================================================================================

    public static final class Contas extends Visao {
        private final PainelRolavel lista = new PainelRolavel(new PainelRolavel.QuebraLayout(FlowLayout.LEFT, 16, 16));
        private final List<CartaoConta> cartoes = new ArrayList<>();

        public Contas(DefaultTableModel modelo, Acoes acoes) {
            super(modelo, acoes);
            setLayout(new BorderLayout());
            lista.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 2, 10, 2));
            add(Tema.rolagemSimples(lista), BorderLayout.CENTER);
        }

        @Override
        public void atualizar() {
            lista.removeAll();
            cartoes.clear();
            // colunas: 0 ID, 1 Plano, 2 E-mail, 3 Senha, 4 Telefone, 5 Pais, 6 Status
            for (int l = 0; l < modelo.getRowCount(); l++) {
                String telefone = texto(l, 4).isEmpty() ? "sem telefone" : texto(l, 4);
                CartaoConta c = new CartaoConta(l, acoes, texto(l, 2), semId(l, 1), texto(l, 5) + "  •  " + telefone, texto(l, 6));
                cartoes.add(c);
                lista.add(c);
            }
            lista.revalidate();
            lista.repaint();
        }

        @Override
        public void marcar(int linha) {
            for (CartaoConta c : cartoes) {
                c.definirSelecionado(c.linha == linha);
            }
        }

        private static final class CartaoConta extends Item {
            private final String email, plano, local, status;

            CartaoConta(int linha, Acoes acoes, String email, String plano, String local, String status) {
                super(linha, acoes);
                this.email = email;
                this.plano = plano;
                this.local = local;
                this.status = status;
                setPreferredSize(new Dimension(370, 156));
                setToolTipText(email);
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = preparar(g);
                int w = getWidth(), h = getHeight();
                g2.setColor(sobre ? new Color(0x2c2c2c) : new Color(0x242424));
                g2.fillRoundRect(0, 0, w, h, 16, 16);
                g2.setColor(Tema.BORDA);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, w - 1, h - 1, 16, 16);

                // etiqueta de status (como o "APARELHO ATUAL" do app)
                Color fundo, letra;
                if ("Ativa".equals(status)) {
                    fundo = new Color(0x16324f);
                    letra = new Color(0x7fb8ff);
                } else if ("Suspensa".equals(status)) {
                    fundo = new Color(0x4a3a10);
                    letra = new Color(0xffd166);
                } else {
                    fundo = new Color(0x4a1418);
                    letra = new Color(0xff7b84);
                }
                g2.setFont(Tema.FONTE_PEQUENA.deriveFont(java.awt.Font.BOLD, 10.5f));
                String etiqueta = status.toUpperCase();
                int larguraEtiqueta = g2.getFontMetrics().stringWidth(etiqueta) + 16;
                g2.setColor(fundo);
                g2.fillRoundRect(18, 16, larguraEtiqueta, 20, 6, 6);
                g2.setColor(letra);
                g2.drawString(etiqueta, 26, 30);

                // e-mail com icone de envelope
                Icone.CONTAS.desenhar(g2, 18, 46, 24, Tema.TEXTO);
                g2.setFont(Tema.FONTE_NEGRITO.deriveFont(16f));
                g2.setColor(Tema.TEXTO);
                g2.drawString(cortar(email, g2.getFontMetrics(), w - 70), 52, 65);

                // linha divisoria e as 2 informacoes com icone
                g2.setColor(Tema.BORDA);
                g2.drawLine(18, 82, w - 18, 82);
                g2.setFont(Tema.FONTE.deriveFont(13.5f));
                g2.setColor(Tema.TEXTO_SUAVE);
                Icone.PLANOS.desenhar(g2, 18, 94, 18, Tema.TEXTO_SUAVE);
                g2.drawString("Plano " + plano, 46, 108);
                Icone.CASA.desenhar(g2, 18, 120, 18, Tema.TEXTO_SUAVE);
                g2.drawString(cortar(local, g2.getFontMetrics(), w - 70), 46, 134);

                contorno(g2, w, h, 16);
                g2.dispose();
            }
        }
    }

    // =====================================================================================
    // HISTORICO: lista "O que foi assistido"
    // =====================================================================================

    public static final class Historico extends Visao {
        private final PainelRolavel lista = new PainelRolavel(null);
        private final List<LinhaHistorico> linhas = new ArrayList<>();

        public Historico(DefaultTableModel modelo, Acoes acoes) {
            super(modelo, acoes);
            lista.setLayout(new BoxLayout(lista, BoxLayout.Y_AXIS));
            lista.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 2, 10, 2));
            setLayout(new BorderLayout());
            add(Tema.rolagemSimples(lista), BorderLayout.CENTER);
        }

        @Override
        public void atualizar() {
            lista.removeAll();
            linhas.clear();
            // colunas: 0 ID, 1 Perfil, 2 Titulo, 3 Minuto, 4 Concluido, 5 Dispositivo, 6 Inicio, 7 Ultima visualizacao, 8 Conta, 9 Plano
            for (int l = 0; l < modelo.getRowCount(); l++) {
                LinhaHistorico item = new LinhaHistorico(l, acoes, semId(l, 2), semId(l, 1) + " (" + texto(l, 8) + ", plano " + texto(l, 9) + ")  •  " + texto(l, 6),
                        "Sim".equals(texto(l, 4)), "parou no minuto " + texto(l, 3) + "  •  " + texto(l, 5));
                linhas.add(item);
                lista.add(item);
                lista.add(javax.swing.Box.createVerticalStrut(10));
            }
            lista.revalidate();
            lista.repaint();
        }

        @Override
        public void marcar(int linha) {
            for (LinhaHistorico l : linhas) {
                l.definirSelecionado(l.linha == linha);
            }
        }

        /** Uma linha: miniatura colorida com o titulo, nome e data, etiqueta de situacao, detalhe e o botao X. */
        private static final class LinhaHistorico extends Item {
            private final String titulo, quando, detalhe;
            private final boolean concluido;
            private boolean sobreX;

            LinhaHistorico(int linha, Acoes acoes, String titulo, String quando, boolean concluido, String detalhe) {
                super(linha, acoes);
                this.titulo = titulo;
                this.quando = quando;
                this.concluido = concluido;
                this.detalhe = detalhe;
                setPreferredSize(new Dimension(300, 88));
                setMaximumSize(new Dimension(Integer.MAX_VALUE, 88));
                setAlignmentX(LEFT_ALIGNMENT);
                setToolTipText("Clique para editar. O X remove do histórico.");
                addMouseMotionListener(new MouseAdapter() {
                    @Override
                    public void mouseMoved(MouseEvent e) {
                        boolean agora = naAreaDoX(e.getX(), e.getY());
                        if (agora != sobreX) {
                            sobreX = agora;
                            repaint();
                        }
                    }
                });
            }

            private boolean naAreaDoX(int x, int y) {
                return x >= getWidth() - 60 && y >= 20 && y <= 68;
            }

            @Override
            protected void aoClicar(int x, int y) {
                if (naAreaDoX(x, y)) {
                    acoes.remover(linha);       // o X: pergunta antes de eliminar
                } else {
                    acoes.selecionar(linha);
                }
            }

            @Override
            protected void aoSair() {
                sobreX = false;
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = preparar(g);
                int w = getWidth(), h = getHeight();
                g2.setColor(sobre ? new Color(0x2a2a2a) : new Color(0x222222));
                g2.fillRoundRect(0, 0, w, h, 14, 14);

                // miniatura: a capa do titulo (imagem da pasta capas ou, sem imagem, a capa desenhada)
                int mw = 124, mh = 68, mx = 10, my = 10;
                Capa.desenhar(g2, titulo, mx, my, mw, mh, 8);
                g2.setColor(Tema.VERMELHO);                       // barrinha vermelha de progresso, como no app
                g2.fillRect(mx, my + mh - 3, concluido ? mw : mw / 3, 3);

                // titulo e data
                int tx = mx + mw + 18;
                int areaTexto = Math.max(120, w - tx - (w > 640 ? 280 : 70)); // sem espaco para a etiqueta: o texto usa tudo
                g2.setFont(Tema.FONTE_NEGRITO.deriveFont(16f));
                g2.setColor(Tema.TEXTO);
                g2.drawString(cortar(titulo, g2.getFontMetrics(), areaTexto), tx, 38);
                g2.setFont(Tema.FONTE.deriveFont(13f));
                g2.setColor(Tema.TEXTO_SUAVE);
                g2.drawString(cortar(quando, g2.getFontMetrics(), areaTexto), tx, 60);

                // etiqueta de situacao e detalhe (so se houver espaco)
                if (w > 640) {
                    int ex = tx + areaTexto + 14;
                    String etiqueta = concluido ? "CONCLUÍDO" : "EM ANDAMENTO";
                    g2.setFont(Tema.FONTE_PEQUENA.deriveFont(java.awt.Font.BOLD, 10.5f));
                    int le = g2.getFontMetrics().stringWidth(etiqueta) + 16;
                    g2.setColor(concluido ? new Color(0x143d22) : new Color(0x4a3a10));
                    g2.fillRoundRect(ex, 22, le, 20, 6, 6);
                    g2.setColor(concluido ? new Color(0x5fd68a) : new Color(0xffd166));
                    g2.drawString(etiqueta, ex + 8, 36);
                    g2.setFont(Tema.FONTE.deriveFont(12.5f));
                    g2.setColor(Tema.TEXTO_SUAVE);
                    g2.drawString(cortar(detalhe, g2.getFontMetrics(), 230), ex, 62);
                }

                // botao X (remover)
                int cx = w - 36, cy = h / 2;
                if (sobreX) {
                    g2.setColor(new Color(0x4a1418));
                    g2.fillOval(cx - 16, cy - 16, 32, 32);
                }
                g2.setColor(sobreX ? new Color(0xff7b84) : Tema.TEXTO_SUAVE);
                g2.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(cx - 6, cy - 6, cx + 6, cy + 6);
                g2.drawLine(cx - 6, cy + 6, cx + 6, cy - 6);

                contorno(g2, w, h, 14);
                g2.dispose();
            }
        }
    }

    // =====================================================================================
    // PLANOS: tabela comparativa
    // =====================================================================================

    public static final class Planos extends Visao {
        private final Comparativo comparativo;

        public Planos(DefaultTableModel modelo, Acoes acoes) {
            super(modelo, acoes);
            comparativo = new Comparativo(modelo, acoes);
            setLayout(new BorderLayout());
            PainelRolavel suporte = new PainelRolavel(new BorderLayout());
            suporte.add(comparativo, BorderLayout.NORTH);
            add(Tema.rolagemSimples(suporte), BorderLayout.CENTER);
        }

        @Override
        public void atualizar() {
            comparativo.repaint();
        }

        @Override
        public void marcar(int linha) {
            comparativo.selecionada = linha;
            comparativo.repaint();
        }

        /** Desenha a comparacao: um quadro colorido por plano em cima e uma linha para cada caracteristica. */
        private static final class Comparativo extends JComponent {
            private final DefaultTableModel modelo;
            private final Visao.Acoes acoes;
            int selecionada = -1;
            private static final int COLUNA_ROTULOS = 210, ALTURA_CABECALHO = 92, ALTURA_LINHA = 58;
            private static final String[] LINHAS = {"Preço por mês", "Qualidade do vídeo", "Telas ao mesmo tempo", "Downloads"};

            Comparativo(DefaultTableModel modelo, Visao.Acoes acoes) {
                this.modelo = modelo;
                this.acoes = acoes;
                setFocusable(true);
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                setToolTipText("Clique em um plano para editar");
                addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        requestFocusInWindow();
                        int linha = linhaNaPosicao(e.getX());
                        if (linha >= 0) {
                            acoes.selecionar(linha);
                        }
                    }
                });
                addKeyListener(new KeyAdapter() { // setas esquerda/direita trocam de plano
                    @Override
                    public void keyPressed(KeyEvent e) {
                        int n = modelo.getRowCount();
                        if (n == 0) {
                            return;
                        }
                        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                            acoes.selecionar(Math.min(n - 1, selecionada + 1));
                        } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                            acoes.selecionar(Math.max(0, selecionada - 1));
                        }
                    }
                });
                addFocusListener(new FocusAdapter() {
                    @Override
                    public void focusGained(FocusEvent e) {
                        repaint();
                    }

                    @Override
                    public void focusLost(FocusEvent e) {
                        repaint();
                    }
                });
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(500, ALTURA_CABECALHO + 20 + LINHAS.length * ALTURA_LINHA + 20);
            }

            private int larguraDoPlano() {
                int n = Math.max(1, modelo.getRowCount());
                return Math.min(170, (getWidth() - COLUNA_ROTULOS - 10) / n);
            }

            private int linhaNaPosicao(int x) {
                int indice = (x - COLUNA_ROTULOS) / Math.max(1, larguraDoPlano());
                return x >= COLUNA_ROTULOS && indice < modelo.getRowCount() ? indice : -1;
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = preparar(g);
                int n = modelo.getRowCount();
                int lp = larguraDoPlano();
                // colunas do modelo: 0 ID, 1 Nome, 2 Descricao, 3 Valor, 4 Qualidade, 5 Telas, 6 Download, 7 Data
                for (int i = 0; i < n; i++) {
                    int x = COLUNA_ROTULOS + i * lp + 8;
                    boolean escolhido = i == selecionada;
                    // quadro do plano (vermelho vivo se escolhido, vinho apagado se nao)
                    g2.setColor(escolhido ? Tema.VERMELHO : new Color(0x5c2228));
                    g2.fillRoundRect(x, 4, lp - 16, ALTURA_CABECALHO - 18, 6, 6);
                    if (escolhido) { // setinha embaixo, como no app
                        Path2D seta = new Path2D.Float();
                        seta.moveTo(x + (lp - 16) / 2.0 - 9, ALTURA_CABECALHO - 14);
                        seta.lineTo(x + (lp - 16) / 2.0 + 9, ALTURA_CABECALHO - 14);
                        seta.lineTo(x + (lp - 16) / 2.0, ALTURA_CABECALHO - 5);
                        seta.closePath();
                        g2.fill(seta);
                    }
                    g2.setColor(Color.WHITE);
                    g2.setFont(Tema.FONTE_NEGRITO.deriveFont(15f));
                    String nome = String.valueOf(modelo.getValueAt(i, 1));
                    textoCentralizado(g2, cortar(nome, g2.getFontMetrics(), lp - 28), x + (lp - 16) / 2, 4 + (ALTURA_CABECALHO - 18) / 2 + 5);
                }

                int topo = ALTURA_CABECALHO + 20;
                for (int r = 0; r < LINHAS.length; r++) {
                    int y = topo + r * ALTURA_LINHA;
                    g2.setColor(Tema.BORDA);                                   // linha separadora
                    g2.setStroke(new BasicStroke(1f));
                    g2.drawLine(0, y, getWidth() - 10, y);
                    g2.setColor(Tema.TEXTO_SUAVE);
                    g2.setFont(Tema.FONTE.deriveFont(14f));
                    g2.drawString(LINHAS[r], 4, y + ALTURA_LINHA / 2 + 5);
                    for (int i = 0; i < n; i++) {
                        int centro = COLUNA_ROTULOS + i * lp + lp / 2;
                        boolean escolhido = i == selecionada;
                        Color cor = escolhido ? new Color(0xff5a63) : Tema.TEXTO;
                        g2.setColor(cor);
                        g2.setFont((escolhido ? Tema.FONTE_NEGRITO : Tema.FONTE).deriveFont(14f));
                        if (r == 0) {
                            textoCentralizado(g2, "R$ " + modelo.getValueAt(i, 3).toString().replace('.', ','), centro, y + ALTURA_LINHA / 2 + 5);
                        } else if (r == 1) {
                            textoCentralizado(g2, String.valueOf(modelo.getValueAt(i, 4)), centro, y + ALTURA_LINHA / 2 + 5);
                        } else if (r == 2) {
                            textoCentralizado(g2, String.valueOf(modelo.getValueAt(i, 5)), centro, y + ALTURA_LINHA / 2 + 5);
                        } else {
                            desenharMarca(g2, centro, y + ALTURA_LINHA / 2, "Sim".equals(String.valueOf(modelo.getValueAt(i, 6))), cor);
                        }
                    }
                }
                g2.setColor(Tema.BORDA);
                g2.drawLine(0, topo + LINHAS.length * ALTURA_LINHA, getWidth() - 10, topo + LINHAS.length * ALTURA_LINHA);
                if (isFocusOwner()) {
                    g2.setColor(Color.WHITE);
                    g2.setStroke(new BasicStroke(2f));
                    g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 8, 8);
                }
                g2.dispose();
            }

            /** Um visto (tem) ou um tracinho (nao tem). */
            private void desenharMarca(Graphics2D g, int cx, int cy, boolean tem, Color cor) {
                g.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                if (tem) {
                    g.setColor(cor);
                    g.drawLine(cx - 8, cy, cx - 3, cy + 6);
                    g.drawLine(cx - 3, cy + 6, cx + 8, cy - 6);
                } else {
                    g.setColor(Tema.TEXTO_SUAVE);
                    g.drawLine(cx - 7, cy, cx + 7, cy);
                }
            }
        }
    }
}
