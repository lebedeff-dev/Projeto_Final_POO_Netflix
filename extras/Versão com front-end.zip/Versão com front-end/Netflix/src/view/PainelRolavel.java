package view;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Rectangle;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.Scrollable;
import javax.swing.SwingUtilities;

/**
 * Painel para colocar dentro de um JScrollPane acompanhando a LARGURA da janela: so rola na vertical.
 * (Um JPanel comum dentro de um JScrollPane fica com a largura que ele quer e passa a rolar na horizontal.)
 * Implementa Scrollable, a interface que o JScrollPane consulta para saber como rolar.
 */
public class PainelRolavel extends JPanel implements Scrollable {

    public PainelRolavel(LayoutManager layout) {
        super(layout);
        setOpaque(false);
    }

    @Override
    public Dimension getPreferredScrollableViewportSize() {
        return getPreferredSize();
    }

    @Override
    public int getScrollableUnitIncrement(Rectangle visivel, int orientacao, int direcao) {
        return 24;
    }

    @Override
    public int getScrollableBlockIncrement(Rectangle visivel, int orientacao, int direcao) {
        return Math.max(24, visivel.height - 24);
    }

    @Override
    public boolean getScrollableTracksViewportWidth() {
        return true; // a largura segue a janela: nada de barra horizontal
    }

    @Override
    public boolean getScrollableTracksViewportHeight() {
        return false;
    }

    /**
     * FlowLayout que QUEBRA LINHA: coloca os componentes lado a lado e, quando acaba a largura,
     * continua na linha de baixo (o FlowLayout comum nao aumenta a altura, entao os de baixo sumiriam).
     */
    public static class QuebraLayout extends FlowLayout {

        public QuebraLayout(int alinhamento, int hgap, int vgap) {
            super(alinhamento, hgap, vgap);
        }

        @Override
        public Dimension preferredLayoutSize(Container alvo) {
            return tamanho(alvo, true);
        }

        @Override
        public Dimension minimumLayoutSize(Container alvo) {
            Dimension minimo = tamanho(alvo, false);
            minimo.width -= getHgap() + 1;
            return minimo;
        }

        private Dimension tamanho(Container alvo, boolean preferido) {
            synchronized (alvo.getTreeLock()) {
                // largura disponivel: a do proprio painel ou, se ainda nao foi medido, a do primeiro "pai" medido
                Container c = alvo;
                while (c.getSize().width == 0 && c.getParent() != null) {
                    c = c.getParent();
                }
                int larguraAlvo = c.getSize().width == 0 ? Integer.MAX_VALUE : c.getSize().width;

                int hgap = getHgap();
                int vgap = getVgap();
                Insets margens = alvo.getInsets();
                int horizontal = margens.left + margens.right + hgap * 2;
                int larguraMaxima = larguraAlvo - horizontal;

                Dimension total = new Dimension(0, 0);
                int larguraLinha = 0;
                int alturaLinha = 0;
                for (Component m : alvo.getComponents()) {
                    if (!m.isVisible()) {
                        continue;
                    }
                    Dimension d = preferido ? m.getPreferredSize() : m.getMinimumSize();
                    if (larguraLinha + d.width > larguraMaxima) { // nao cabe: fecha a linha e comeca outra
                        acrescentarLinha(total, larguraLinha, alturaLinha);
                        larguraLinha = 0;
                        alturaLinha = 0;
                    }
                    if (larguraLinha != 0) {
                        larguraLinha += hgap;
                    }
                    larguraLinha += d.width;
                    alturaLinha = Math.max(alturaLinha, d.height);
                }
                acrescentarLinha(total, larguraLinha, alturaLinha);

                total.width += horizontal;
                total.height += margens.top + margens.bottom + vgap * 2;
                Container rolagem = SwingUtilities.getAncestorOfClass(JScrollPane.class, alvo);
                if (rolagem != null && alvo.isValid()) {
                    total.width -= hgap + 1;
                }
                return total;
            }
        }

        private void acrescentarLinha(Dimension total, int larguraLinha, int alturaLinha) {
            total.width = Math.max(total.width, larguraLinha);
            if (total.height > 0) {
                total.height += getVgap();
            }
            total.height += alturaLinha;
        }
    }
}
