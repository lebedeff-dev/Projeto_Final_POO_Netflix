---
tags: [netflix, fora-da-aula, excecoes, controller]
---

# Validação com exceções (`IllegalArgumentException`)

> [!info] O que o professor mostrou
> `try/catch` e `throws` para erros de SQL e de driver. **Não mostrou criar/lançar exceção (`throw new ...`) para validar dado do usuário**, nem `catch` com dois tipos.

## A ideia

Tudo que o usuário digita chega como `String`. Antes de gravar, o Controller precisa conferir. Em vez de devolver códigos de erro, o `Conversor` **lança uma exceção com a mensagem pronta** e o Controller a captura e devolve o texto para a tela.

```java
// Conversor.java
public static String obrigatorio(String texto, String campo) {
    if (texto == null || texto.trim().isEmpty()) {
        throw new IllegalArgumentException("O campo '" + campo + "' é obrigatório.");
    }
    return texto.trim();
}
```
| Trecho | O que faz |
|---|---|
| `texto == null \|\| texto.trim().isEmpty()` | Vazio ou só espaços |
| `throw new IllegalArgumentException(msg)` | **Interrompe** o método e "joga" o erro para quem chamou |
| `IllegalArgumentException` | Exceção padrão do Java para "argumento inválido"; é *unchecked* (não precisa declarar `throws`) |
| `return texto.trim()` | Se está certo, devolve o texto sem espaços nas pontas |

## Quem captura

```java
// PlanoController.inserir
try {
    dao.inserir(montar(nome, valorMensal, ...));   // montar() pode lançar IllegalArgumentException
    return "Plano inserido com sucesso!";
} catch (IllegalArgumentException e) {  // erro de validação (Conversor)
    return e.getMessage();              // a mensagem que o Conversor escreveu
} catch (SQLException e) {              // erro do banco (inclusive MySQL desligado)
    return "Erro no banco de dados: " + e.getMessage();
}
```
- **Dois `catch` em sequência:** cada um trata um tipo de erro diferente.
- A tela só mostra o texto que voltou. Ela nunca sabe se foi erro de validação ou de banco.

## Regras de negócio (também viram exceção)

| Onde | Regra |
|---|---|
| `PlanoController` | valor > 0 e pelo menos 1 tela |
| `PerfilController` | PIN com exatamente 4 dígitos |
| `ContaController` | país com 2 letras |
| `HistoricoController` | última visualização não pode ser antes do início; minuto de parada não pode ser negativo nem passar da duração do título |
| `RelatorioController` | data final não pode ser anterior à inicial |

## Outras exceções que aparecem

| Código | Para quê |
|---|---|
| `catch (NumberFormatException e)` em `Conversor.paraInt` | `Integer.parseInt("abc")` falha; trocamos por "deve ser um número inteiro" |
| `catch (DateTimeParseException e)` | data em formato errado |
| `catch (IOException \| NumberFormatException e)` | **multi-catch** (`\|`): trata dois tipos com o mesmo código (ler `config.properties`) |
| `throw new RuntimeException("Erro ao listar...", e)` nos `listar()` | Listar devolve `List`, não `String`; então o erro sobe como `RuntimeException` e `TelaCrud.recarregar` mostra a mensagem |

> [!tip] Checked x unchecked
> `SQLException` e `IOException` são **checked**: o compilador obriga `throws` ou `catch`. `IllegalArgumentException` e `RuntimeException` são **unchecked**: não obrigam. Por isso o DAO declara `throws SQLException` e o `Conversor` não declara nada.

> [!codigo] Como responder
> **"Onde está a validação?"** — "No Controller, usando o `Conversor`. Se o dado é inválido ele lança `IllegalArgumentException` com a mensagem; o Controller captura e devolve o texto para a tela mostrar. A tela não valida nada."

---
⬅ [[Fora da aula - Índice]] · [[Conversor]] · [[Pacote controller]] · [[Perguntas - controller]]
