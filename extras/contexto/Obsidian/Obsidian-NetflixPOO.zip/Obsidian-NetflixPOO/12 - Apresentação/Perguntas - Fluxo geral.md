---
tags: [netflix, apresentacao]
---

# Perguntas - Fluxo geral

*Seção 12.1: Fluxo geral e execução* · Pasta: [[Perguntas do professor]]


| Pergunta | Resposta |
|---|---|
| Explique o caminho do clique em **Inserir** até o banco. | `btnInserir` → `mostrarResultado(inserir())` ([[TelaCrud]]) → [[Telas filhas\|TelaPlano]]`.inserir()` lê os campos com `valor(...)` → [[PlanoController]]`.inserir(...)` converte com o [[Conversor]] e monta um [[Pacote model\|Plano]] → [[PlanoDAO]]`.inserir(plano)` pega a conexão da [[ConnectionFactory]], prepara o INSERT e executa → volta a mensagem → `JOptionPane` e `recarregar()`. |
| Por que a tela não chama o [[PlanoDAO]] direto? | MVC: a tela só cuida da interface; validação e regras no Controller; SQL no DAO. Trocar o banco ou a tela não quebra o resto. |
| Onde fica o `main`? | Em [[Main]]`.java`: `SwingUtilities.invokeLater(() -> new TelaConexao().setVisible(true))`. O manifesto do jar aponta `Main-Class: Main`. |
| Qual é o CRUD principal e por quê? | `historico_visualizacao` ([[Telas filhas\|TelaHistorico]], [[HistoricoController]], [[HistoricoVisualizacaoDAO]]): é a rotina central (o que cada perfil assiste) e relaciona perfil e título por duas FKs. |
| Qual é o relatório e por que ele é da rotina principal? | "Visualizações por período (e por perfil)": [[TelaRelatorio]] → [[RelatorioController]]`.gerar` → [[HistoricoVisualizacaoDAO]]`.listarPorPeriodo`. Trabalha com o histórico (CRUD principal), com JOIN, filtros e totais. |
| Como o banco é criado? | [[ConexaoController]]`.conectar` chama [[CriadorBanco]]`.criarSeNaoExistir()`, que consulta `information_schema.schemata` e, se o banco não existe, lê o `netflix.sql` de dentro do jar e executa comando por comando (`split(";")` + `Statement.execute`). |
| O que o `build.bat` faz? | Compila `src/` com o driver no classpath, copia o `netflix.sql`, extrai o driver para dentro e monta o `Netflix.jar` com `Main-Class: Main`. |

---
⬅ [[Perguntas do professor]] · [[00 - Painel]] · [[Perguntas - Banco de dados]] ➡
