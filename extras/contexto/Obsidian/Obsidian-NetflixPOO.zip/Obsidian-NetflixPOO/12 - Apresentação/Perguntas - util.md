---
tags: [netflix, apresentacao]
---

# Perguntas - util

*Seção 12.3: util* · Pasta: [[Perguntas do professor]]


| Pergunta | Resposta |
|---|---|
| Por que existe a [[ConnectionFactory]]? | Concentra os dados de conexão em um lugar; os DAOs só chamam `getConnection()`. |
| Onde fica a senha do MySQL na versão principal? | Não fica no código: a [[TelaConexao]] pede, a [[ConnectionFactory]] guarda nos atributos estáticos e grava no `config.properties` (`Properties.store`). Na próxima vez é lida com `Properties.load`. |
| Por que o construtor da [[ConnectionFactory]] é `private`? | Só tem métodos `static`; impede `new ConnectionFactory()`. |
| Onde o driver é carregado, se não tem `Class.forName`? | Desde o JDBC 4 o `DriverManager` carrega sozinho o driver que está no classpath (arquivo `META-INF/services/java.sql.Driver` do conector, que vai dentro do jar). |
| Por que `getConnection()` declara `throws SQLException`? | O erro de conexão segue o mesmo caminho de qualquer erro de banco: DAO repassa, Controller captura e devolve a mensagem. |
| Por que o [[CriadorBanco]] usa `Statement` e não `PreparedStatement`? | O script não tem valores vindos do usuário (sem risco de SQL Injection) e não tem `?`. |
| Por que o `split(";")`? | O JDBC executa um comando por vez; o script tem 13 comandos separados por `;`. |
| O que faz [[Conversor]]`.opcao(3, "Premium")`? | Devolve `"3 - Premium"`, usado no combo e na tabela. `extrairId` faz o inverso (pega o 3 para gravar a FK). |
| Por que `"Sim".equals(texto)`? | Se `texto` for `null` não dá `NullPointerException`. |
| Por que `paraIntOuNulo` devolve `Integer`? | Precisa poder devolver `null` (duração vazia de série). |

---
⬅ [[Perguntas - Banco de dados]] · [[00 - Painel]] · [[Perguntas - model]] ➡
