---
tags: [netflix, apresentacao]
---

# Perguntas - Banco de dados

*Seção 12.2: Banco de dados* · Pasta: [[Perguntas do professor]]


| Pergunta | Resposta |
|---|---|
| Por que o script começa com `DROP DATABASE IF EXISTS`? | Para poder rodar várias vezes (botão Restaurar): apaga o banco antigo e recria do zero. `IF EXISTS` evita erro na primeira vez. |
| Por que a ordem plano, conta, perfil, titulo, historico? | Uma tabela só pode referenciar (FK) outra que já existe. Os INSERT seguem a mesma ordem. |
| Quais são as PKs e FKs? | 5 PKs (`id_plano`, `id_conta`, `id_perfil`, `id_titulo`, `id_visualizacao`) e 4 FKs: `conta.id_plano`, `perfil.id_conta`, `historico_visualizacao.id_perfil` e `.id_titulo`. |
| Qual tabela é associativa? | `historico_visualizacao`: resolve o N:N entre perfil e título e guarda dados da sessão. |
| O que acontece ao apagar o plano Premium? | A FK sem CASCADE impede (há conta usando); a `SQLException` vira "Não foi possível remover...". |
| O que acontece ao apagar o perfil Pedro? | `ON DELETE CASCADE` apaga junto o histórico dele. |
| Por que CASCADE só no histórico? | Histórico sem perfil/título não faz sentido; nos outros preferimos **bloquear** para não apagar dados sem querer. |
| Por que `DECIMAL(6,2)` e `BigDecimal`? | Dinheiro precisa de decimal exato; FLOAT/double arredondam. |
| Por que `TINYINT(1)`? | O MySQL não tem booleano; guarda 0/1 e vira `boolean` no Java. |
| Por que `ENUM`? | Só aceita valores de uma lista; os combos oferecem exatamente os mesmos valores. |
| O que é `ENGINE=InnoDB`? | O motor que suporta FKs e transações. |

---
⬅ [[Perguntas - Fluxo geral]] · [[00 - Painel]] · [[Perguntas - util]] ➡
