---
tags: [netflix, codigo, util, classe]
---

# Conversor

*Seção 3.3: Conversor* · Pasta: [[Pacote util]]


**Para que serve:** a View entrega tudo como texto (`String`). O Controller usa o `Conversor` para transformar em `int`, `BigDecimal`, `LocalDate` etc. e validar. Texto inválido → `IllegalArgumentException` com mensagem em português; o Controller captura e devolve essa mensagem para a tela.

- `DATA = DateTimeFormatter.ofPattern("dd/MM/uuuu")` (com `ResolverStyle.STRICT`, que recusa 31/02): molde da data digitada, no formato brasileiro.
- `DATA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")`: molde de data com hora para **mostrar** (ex.: `01/06/2025 20:00`). Para trocar a ordem, muda só essa linha.
- `obrigatorio(texto, campo)`: se `texto == null || texto.trim().isEmpty()`, lança "O campo 'X' é obrigatório."; senão devolve `texto.trim()`.
- `vazioParaNulo(texto)`: operador ternário `condição ? seVerdade : seFalso`. Vazio vira `null` (que o DAO grava como NULL).
- `paraInt` / `paraIntOuNulo`: `Integer.parseInt`; o `catch (NumberFormatException e)` troca o erro técnico por "deve ser um número inteiro". `paraIntOuNulo` devolve `Integer` (objeto) porque pode ser `null`.
- `paraDecimal`: `new BigDecimal(texto.replace(',', '.'))`: o usuário digita `29,90` e o `BigDecimal` só entende `29.90`.
- `paraData`: `LocalDate.parse(texto, DATA)` (dd/mm/aaaa). Só o Relatório pede data digitada.
- `paraBoolean(texto)`: `"Sim".equals(texto)`; escrito assim (e não `texto.equals("Sim")`) para não dar `NullPointerException` se `texto` for `null`.
- `simNao(valor)`: boolean → "Sim"/"Nao" para a tabela.
- **`opcao(int id, String nome)` (novo):** devolve `id + " - " + nome` (ex.: `"3 - Premium"`). É usado **nos combos e nas colunas das tabelas**. Como o texto é idêntico, ao clicar numa linha o combo encontra o mesmo item e se posiciona sozinho.
- `extrairId(opcao, campo)`: o inverso: `opcao.split(" - ")[0]` pega o `"3"` e converte para `int` (a FK a gravar). Combo vazio → "Selecione um valor em 'Plano'."
- `paraId(texto)`: id da linha selecionada; vazio → "Selecione um registro na tabela primeiro."
- `formatarDataHora` (mostra data e hora nas tabelas e no .txt) e `hoje()` (data final padrão do Relatório).

---
⬅ [[CriadorBanco]] · [[00 - Painel]] · [[Pacote model]] ➡
