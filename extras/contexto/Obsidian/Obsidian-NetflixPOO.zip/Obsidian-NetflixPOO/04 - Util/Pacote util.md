---
tags: [netflix, codigo, util]
---

# Pacote util

*Seção 3 da documentação: Pacote util*


Classes de apoio usadas por várias camadas.

## Notas desta pasta

- [[ConnectionFactory]]: ConnectionFactory (mudou na versão principal)
- [[CriadorBanco]]: CriadorBanco (novo na versão principal)
- [[Conversor]]: Conversor

---
⬅ [[Banco de dados]] · [[00 - Painel]] · [[ConnectionFactory]] ➡
