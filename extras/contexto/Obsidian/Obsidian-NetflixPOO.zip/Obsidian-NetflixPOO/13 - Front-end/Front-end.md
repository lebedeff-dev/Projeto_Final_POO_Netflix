---
tags: [netflix, front-end, visual]
---

# Front-end (visual novo)

*Como foi feito cada pedaço do visual da versão com front-end, em linguagem simples, para explicar na apresentação.*

> [!info] Duas versões, dois diretórios no GitHub
> - **`Projeto/`** = versão principal, com a aparência padrão do Swing.
> - **`Projeto (front-end)/`** = a mesma versão com o visual novo (tema escuro, capas, cartões). **Não se misturam.**
>
> O funcionamento (CRUDs, JOIN, relatório, banco) e a **lógica de navegação** (barra no topo, uma janela por vez, fade-in) são **os mesmos** nas duas; muda só a **aparência**. As notas desta pasta explicam o visual novo; a navegação da versão padrão está em [[Nota versão principal]].

> [!regra] Regras da proposta que continuam valendo
> Java + **Swing com `JFrame`** · `JTable` + `DefaultTableModel` · MVC (a aparência fica na View; Controller e DAO não sabem que o visual mudou) · 4 CRUDs simples completos + CRUD principal completo · consulta com INNER JOIN mostrando nomes · relatório da rotina principal.

> [!tip] Lembrete para a apresentação
> O **Histórico de Visualização é o CRUD principal** (a rotina principal do sistema). Na tela ele **não** tem o texto "CRUD principal": é um botão como os outros na barra do topo. Quem fala isso é a apresentação.

## Mapa do front-end

| Peça | O que faz | Nota |
|---|---|---|
| Cores, fontes, botão, campos, tabela | O "tema escuro Netflix" | [[Tema]] |
| Tela Início, destaque e capas | Página inicial com fileiras de capas | [[Início e capas]] |
| Barra do topo e troca de tela | Botões ao lado do logo e transição suave | [[Navegação e transição]] |
| Avatares, cartões, lista e comparativo | A forma "Visual" das 4 abas | [[Visões das abas]] |

## Ideia geral em 4 frases

1. Nada de imagem para a interface: botões, ícones, avatares e cartões são **desenhados em código** (Java2D: `paintComponent` + `Graphics2D`). Só as capas dos filmes são imagens (opcionais).
2. Cada desenho continua sendo um componente Swing comum (`JButton`, `JPanel`) com o `paintComponent` sobrescrito (**herança + sobrescrita**).
3. As telas só **mostram** o que os Controllers devolvem e **avisam** o Controller quando algo acontece.
4. Sem animações complicadas: só um fade-in curto ao trocar de tela.

## Arquivos (pasta `view`)

`Tema` · `Icone` · `Capa` · `BarraNavegacao` · `Navegador` · `TelaPrincipal` · `TelaCrud` · `Visao` · `Visoes` · `PainelRolavel` · `TelaRelatorio` · `TelaConexao`

> [!warning] Direitos autorais
> A pasta `capas` (pôsteres) **não** foi publicada. Sem ela o sistema desenha as capas em código e funciona normalmente.

---
⬅ [[Pacote view]] · [[00 - Painel]] · [[Tema]] · [[Nota versão principal]] ➡
