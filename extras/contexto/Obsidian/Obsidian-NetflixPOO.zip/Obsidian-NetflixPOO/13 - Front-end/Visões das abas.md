---
tags: [netflix, front-end, visoes]
---

# Visões das abas (`Visao.java`, `Visoes.java`, `PainelRolavel.java`)

*As abas Perfis, Contas, Histórico e Planos têm duas formas de mostrar os mesmos dados: **Visual** e **Tabela**.*

## O que cada aba mostra no modo Visual

| Aba | Desenho |
|---|---|
| Perfis | Avatares coloridos com carinha; o perfil infantil vira "KiDS"; um quadrado tracejado "Novo perfil" |
| Contas | Cartões com etiqueta de status (Ativa / Suspensa / Cancelada), e-mail, plano, país, telefone e cadastro |
| Histórico de Visualização | Lista com a **capa do título**, perfil, data, etiqueta Concluído/Em andamento e o **X** para remover |
| Planos | Tabela comparativa (preço, qualidade, telas, downloads); clique ou setas ← → trocam o plano |

Títulos continua só com a tabela.

## Como foi feito

- **`Visao`** (classe abstrata, `extends JPanel`): guarda o `DefaultTableModel` e define o que toda visão faz: `atualizar()` (refaz os desenhos a partir das linhas do modelo) e `marcar(linha)` (destaca o selecionado). A interface interna **`Visao.Acoes`** (`selecionar`, `remover`, `novo`) é como a visão **avisa** a tela.
- **`Visoes`**: as quatro visões. Cada desenho é um componente que sobrescreve `paintComponent` (Java2D) e lê o texto das células do modelo (ex.: `modelo.getValueAt(linha, 2)`).
- **`TelaCrud`** (Template Method): tem o gancho `criarVisao(...)`, que devolve `null` por padrão (só tabela). `TelaPerfil`, `TelaConta`, `TelaHistorico` e `TelaPlano` sobrescrevem e devolvem a sua visão (**polimorfismo**).
- **Alternar Visual/Tabela**: `CardLayout` (mostra uma "carta" de cada vez) com dois botões `Tema.Botao`; o botão ativo usa `setTipo(PRINCIPAL)`.
- **Formulário à direita** ("Detalhes"): o mesmo formulário de antes, em 1 ou 2 colunas. Inserir, Alterar, Remover e Limpar **não mudaram**.
- **`AcoesDaTela`** (classe interna da `TelaCrud`): `selecionar(linha)` faz `tabela.setRowSelectionInterval(...)`, o que dispara o mesmo listener que já preenche o formulário; `remover(linha)` seleciona e chama `confirmarEliminar()` (a **mesma** pergunta do botão Remover). Assim clicar num desenho usa **a mesma lógica** dos botões.
- **`PainelRolavel`**: painel que implementa `Scrollable` (só rola na vertical, acompanha a largura da janela) e um `FlowLayout` que **quebra linha** para os cartões irem para baixo quando a janela é estreita.

> [!regra] MVC preservado
> A visão **não acessa banco nem Controller**: lê o `DefaultTableModel` que o Controller já preencheu e avisa a tela pela interface `Acoes`.

> [!codigo] Pergunta provável
> **Por que a visão usa o modelo da tabela e não busca de novo no banco?** Para não duplicar acesso a dados: a fonte é uma só (`carregarTabela()` → Controller → DAO). Tabela e visão sempre mostram o mesmo.

> [!codigo] Pergunta provável
> **O que é o `CardLayout`?** Um gerenciador de layout que empilha painéis e mostra só um por vez (`cartas.show(conteudo, "tabela")`).

---
⬅ [[Navegação e transição]] · [[Front-end]] · [[00 - Painel]]
