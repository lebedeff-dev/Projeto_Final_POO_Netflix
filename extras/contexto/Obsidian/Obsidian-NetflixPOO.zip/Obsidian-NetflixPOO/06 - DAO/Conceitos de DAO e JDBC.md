---
tags: [netflix, codigo, dao]
---

# Conceitos de DAO e JDBC

*Seção 5.1: Conceitos que o professor vai cobrar* · Pasta: [[Pacote dao]]


- **PreparedStatement e SQL Injection.** No SQL escrevemos `?` no lugar dos valores e depois enviamos os valores com `ps.setString(1, ...)`, `ps.setInt(2, ...)`. O banco recebe comando e dados **separados**: o dado é sempre valor, nunca código SQL. Se concatenássemos (`"... WHERE nome = '" + nome + "'"`) e o usuário digitasse `x' OR '1'='1`, ele alteraria o comando (**SQL Injection**). Os números dos `setX(n, valor)` começam em 1 e seguem a ordem dos `?`.
- **try-with-resources.** `try (Connection con = ...; PreparedStatement ps = ...) { ... }`: tudo nos parênteses é fechado **automaticamente** ao sair do bloco, mesmo com erro (na ordem inversa). Evita "vazamento de conexão".
- **executeUpdate x executeQuery.** `executeUpdate()` roda INSERT/UPDATE/DELETE; `executeQuery()` roda SELECT e devolve um `ResultSet`.
- **ResultSet.** A tabela resultado do SELECT. `rs.next()` avança uma linha e devolve `false` quando acabam; `rs.getInt("id_plano")`, `rs.getString("nome")` leem colunas pelo nome.
- **camelCase ↔ snake_case:** `plano.getValorMensal()` → coluna `valor_mensal`, e `rs.getBigDecimal("valor_mensal")` → `setValorMensal(...)`.
- **`throws SQLException`:** o DAO não trata o erro; repassa ao Controller, que decide a mensagem. O DAO não mostra janelas.
- **Datas:** gravar com `Date.valueOf(localDate)` / `Timestamp.valueOf(localDateTime)`; ler com `rs.getDate(...).toLocalDate()` / `rs.getTimestamp(...).toLocalDateTime()`.

---
⬅ [[Pacote dao]] · [[00 - Painel]] · [[PlanoDAO]] ➡
