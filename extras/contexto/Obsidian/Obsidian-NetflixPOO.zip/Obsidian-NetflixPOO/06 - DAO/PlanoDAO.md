---
tags: [netflix, codigo, dao, classe]
---

# PlanoDAO

*Seção 5.2: PlanoDAO (referência: os outros seguem o mesmo molde)* · Pasta: [[Pacote dao]]


**`inserir(Plano p)`**
- `String sql = "INSERT INTO plano (nome, descricao, valor_mensal, qualidade_maxima, telas_simultaneas, permite_download, data_criacao) VALUES (?, ?, ?, ?, ?, ?, CURDATE())";`: 7 colunas, 6 `?` (o id e a data de criação o banco preenche: `AUTO_INCREMENT` e `CURDATE()`).
- `try (Connection con = ConnectionFactory.getConnection(); PreparedStatement ps = con.prepareStatement(sql))`: abre a conexão e prepara o comando.
- `ps.setString(1, p.getNome())` ... `ps.setBoolean(6, p.isPermiteDownload())`: preenche cada `?` na ordem (`setString` aceita `null` e grava NULL; `setBoolean` vira 0/1).
- `ps.executeUpdate();`: **executa o INSERT**.

**`listar()`**
- `SELECT ... FROM plano ORDER BY id_plano`; `List<Plano> lista = new ArrayList<>();`
- `try (... ResultSet rs = ps.executeQuery())` e `while (rs.next()) { lista.add(montarPlano(rs)); }`.
- `return lista;` fica depois do `try`: quando roda, `rs`, `ps` e `con` já foram fechados.

**`atualizar(Plano p)`**: `UPDATE plano SET nome = ?, ... WHERE id_plano = ?`; os 7 primeiros `?` como no insert e `ps.setInt(8, p.getIdPlano())` no `WHERE`. **Sem o WHERE, todos os planos seriam alterados.**

**`eliminar(int idPlano)`**: `DELETE FROM plano WHERE id_plano = ?`. Se o plano tiver contas, o MySQL recusa (FK) e lança `SQLException`.

**`montarPlano(ResultSet rs)`** (privado): `new Plano()` e um `setX(rs.getX("coluna"))` por coluna. Evita repetir código.

---
⬅ [[Conceitos de DAO e JDBC]] · [[00 - Painel]] · [[ContaDAO]] ➡
