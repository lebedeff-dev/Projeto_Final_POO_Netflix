---
tags: [netflix, codigo, dao, classe]
---

# TituloDAO

*Seção 5.5: TituloDAO* · Pasta: [[Pacote dao]]


Igual à primeira versão, com cuidado para `duracao_minutos` NULL:
- `preencher(ps, t)`: método auxiliar que preenche os 9 `?` comuns ao INSERT e ao UPDATE. Para a duração: `if (t.getDuracaoMinutos() == null) { ps.setNull(6, Types.INTEGER); } else { ps.setInt(6, t.getDuracaoMinutos()); }`. `setInt` não aceita `null`, por isso `setNull` informando o tipo SQL.
- `listar`: `int duracao = rs.getInt("duracao_minutos"); t.setDuracaoMinutos(rs.wasNull() ? null : duracao);`. `getInt` devolve 0 quando é NULL; `wasNull()` diz se o último valor lido era NULL.
- `buscarPorId(id)`: `SELECT ... WHERE id_titulo = ?` com `ps.setInt(1, id)`; devolve o `Titulo` ou `null` se não existir (`return rs.next() ? montar(rs) : null;`). É o mesmo padrão do `select ... where` do exemplo do professor. O `HistoricoController` o usa para saber a duração.
- `montar(rs)`: converte a linha atual do `ResultSet` em `Titulo`; `listar` e `buscarPorId` o reutilizam.

---
⬅ [[PerfilDAO]] · [[00 - Painel]] · [[HistoricoVisualizacaoDAO]] ➡
