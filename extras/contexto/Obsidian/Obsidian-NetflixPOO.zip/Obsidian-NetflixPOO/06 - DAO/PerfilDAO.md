---
tags: [netflix, codigo, dao, classe]
---

# PerfilDAO

*Seção 5.4: PerfilDAO (mudou: listar com INNER JOIN)* · Pasta: [[Pacote dao]]


`listar()` faz `FROM perfil p INNER JOIN conta c ON c.id_conta = p.id_conta` e traz `c.email AS email_conta`, lido com `p.setEmailConta(rs.getString("email_conta"))`. `eliminar`: por causa do `ON DELETE CASCADE`, o histórico do perfil é apagado junto.

---
⬅ [[ContaDAO]] · [[00 - Painel]] · [[TituloDAO]] ➡
