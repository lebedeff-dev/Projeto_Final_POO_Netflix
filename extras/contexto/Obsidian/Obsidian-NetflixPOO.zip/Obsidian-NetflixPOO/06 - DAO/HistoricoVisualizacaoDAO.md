---
tags: [netflix, codigo, dao, classe]
---

# HistoricoVisualizacaoDAO

*Seção 5.6: HistoricoVisualizacaoDAO (CRUD principal + consultas do relatório)* · Pasta: [[Pacote dao]]


- **`SELECT_COM_NOMES` (constante privada):** a parte comum das duas consultas com INNER JOIN (escrita uma vez só):
  ```sql
  SELECT h.id_visualizacao, h.id_perfil, h.id_titulo, h.data_inicio,
         h.data_ultima_visualizacao, h.minuto_parada, h.concluido, h.dispositivo,
         p.nome AS nome_perfil, t.nome AS nome_titulo,
         c.email AS email_conta, pl.nome AS nome_plano
  FROM historico_visualizacao h
  INNER JOIN perfil p ON p.id_perfil = h.id_perfil
  INNER JOIN titulo t ON t.id_titulo = h.id_titulo
  INNER JOIN conta c ON c.id_conta = p.id_conta
  INNER JOIN plano pl ON pl.id_plano = c.id_plano
  ```
  Os apelidos `nome_perfil`, `nome_titulo` e `nome_plano` são necessários porque perfil, título e plano têm uma coluna `nome`. O JOIN com `conta` e `plano` mostra, para cada visualização, **de qual conta e de qual plano** é o perfil (perfil → conta → plano).
- `inserir`, `atualizar`, `eliminar`: iguais à primeira versão. Gravam as 2 FKs, as datas com `Timestamp.valueOf`, minuto, concluído e dispositivo (os nomes não são gravados).
- **`listarComNomes()`**: `SELECT_COM_NOMES + "ORDER BY h.data_ultima_visualizacao DESC"` (mais recentes primeiro). É o **Read** do CRUD principal e a **consulta obrigatória com JOIN**.
- **`listarPorPeriodo(dataInicial, dataFinal, idPerfil)` (novo, do relatório):**
  - `String sql = SELECT_COM_NOMES + "WHERE DATE(h.data_inicio) BETWEEN ? AND ? ";`: `DATE(...)` tira a hora do DATETIME; `BETWEEN` inclui as duas pontas.
  - `if (idPerfil > 0) { sql += "AND h.id_perfil = ? "; }`: filtro **opcional**: só entra se um perfil foi escolhido (0 = "Todos").
  - `sql += "ORDER BY h.data_inicio";`: ordem cronológica.
  - `ps.setDate(1, Date.valueOf(dataInicial)); ps.setDate(2, Date.valueOf(dataFinal)); if (idPerfil > 0) { ps.setInt(3, idPerfil); }`: o terceiro `?` só existe se o filtro foi acrescentado.
- **`montar(ResultSet rs)`** (privado): converte a linha atual em [[Pacote model|HistoricoVisualizacao]], incluindo `setNomePerfil(rs.getString("nome_perfil"))` e `setNomeTitulo(...)`. Usado pelas duas consultas.

---
⬅ [[TituloDAO]] · [[00 - Painel]] · [[Pacote controller]] ➡
