---
tags: [netflix, projeto]
---

# O que mudou da primeira versão para a versão principal

*Seção 0 da documentação: O que mudou da primeira versão para a versão principal*


| Problema na primeira versão | Como a versão principal resolve | Onde no código |
|---|---|---|
| **Faltava o relatório** da rotina principal (a proposta pede JOIN **e** relatório; a primeira versão só tinha a tabela do JOIN) | Nova tela **Relatório: visualizações por período**, com filtro de datas e de perfil, totais (concluídas, em andamento, minutos) e botão **Salvar .txt** | [[TelaRelatorio]], [[RelatorioController]], [[HistoricoVisualizacaoDAO]]`.listarPorPeriodo()` |
| Não tinha **build**: cada um precisava compilar | `Netflix.jar` pronto (com o driver do MySQL e o script SQL dentro). Dois cliques e abre | `Netflix.jar`, `Netflix/build.bat` |
| Tinha que abrir o **Workbench** e rodar o script na mão | O sistema cria o banco **sozinho** na primeira vez. O menu tem **Restaurar dados de exemplo** | `util/CriadorBanco` |
| A senha do MySQL ficava **escrita no código** (editar e recompilar) | **Tela de conexão** ao abrir; os dados ficam salvos em `config.properties` | [[TelaConexao]], [[ConexaoController]], [[ConnectionFactory]] |
| Contas e Perfis mostravam **só o número da FK** ("Plano (id) = 3"), o que a proposta pede para evitar | As tabelas mostram **"3 - Premium"** e **"1 - ana.silva@email.com"** (INNER JOIN em [[ContaDAO]] e [[PerfilDAO]]) | [[ContaDAO]]`.listar`, [[PerfilDAO]]`.listar` |
| Código difícil de explicar: `Supplier<String>`, `this::inserir`, `TelaPlano::new`, colunas escondidas no Histórico | Botões chamam o método direto (`e -> mostrarResultado(inserir())`); colunas escondidas eliminadas porque tabela e combo usam o mesmo texto `"id - nome"` | [[TelaCrud]], [[Telas filhas\|TelaHistorico]], [[TelaPrincipal]] |
| Combos de FK **não atualizavam** (cadastrar um plano e ele não aparecer na tela de Conta) | Combos recarregam junto com a tabela, depois de cada ação (`carregarCombos()`) | [[TelaCrud]]`.recarregar()` |
| [[ConnectionFactory]] lançava `RuntimeException` | Lança `SQLException`. Assim o erro "MySQL desligado" cai no mesmo `catch (SQLException)` dos controllers | [[ConnectionFactory]]`.getConnection()` |

O **modelo do banco é o mesmo da primeira versão** (5 tabelas, mesmas colunas e dados de exemplo).

---
⬅ [[Requisitos da proposta]] · [[00 - Painel]] · [[Visão geral]] ➡
