---
tags: [netflix, roteiro, perguntas]
---

# Perguntas prováveis do professor sobre o que **não** foi dado em aula

> [!info] Por quê
> O professor pergunta **individualmente** (2 perguntas × 0,5 ponto). Ele não mostrou em aula os recursos abaixo; então ele pode perguntar "o que é isso e por que usou?". Respostas curtas; detalhes em [[Fora da aula - Índice]].

| Pergunta | Resposta em uma frase | Nota |
|---|---|---|
| O que é `abstract` na `TelaCrud`? | A classe define o esqueleto e obriga as filhas a implementar `inserir`, `atualizar`, `eliminar` e `carregarTabela` (Template Method) | [[Classe abstrata e Template Method]] |
| O que é `->` (seta)? | Lambda: forma curta do `ActionListener` ("quando clicar, faça isto") | [[Lambda e eventos]] |
| O que é `try (...)`? | try-with-resources: fecha `Connection`, `PreparedStatement` e `ResultSet` sozinho | [[try-with-resources e JDBC além da aula]] |
| Por que `setNull(i, Types.INTEGER)`? | Série não tem duração; grava `NULL` e não 0 | [[try-with-resources e JDBC além da aula]] |
| O que é `INNER JOIN`? Qual é o seu? | Une tabelas pelo que têm em comum; o nosso junta 5 tabelas (histórico, perfil, conta, plano, título) | [[SQL além da aula]] |
| O que é `ON DELETE CASCADE`? | Apagar o pai apaga os filhos; só no histórico. Nas outras FKs o Controller bloqueia com mensagem (erro 1451) | [[SQL além da aula]] |
| Por que `PreparedStatement`? | Parâmetros `?` evitam SQL injection | [[Conceitos de DAO e JDBC]] |
| O que é `LocalDate`/`LocalDateTime`? | Tipos de data do Java; convertidos para `Date`/`Timestamp` no JDBC | [[Datas e números]] |
| Por que `BigDecimal` para o valor? | Dinheiro não pode ter erro de arredondamento do `double` | [[Datas e números]] |
| O que é `IllegalArgumentException` aqui? | A validação lança; o Controller captura e devolve a mensagem para a tela | [[Validação com exceções]] |
| O que é `Properties`/`config.properties`? | Arquivo de pares chave=valor com servidor, porta, usuário e senha | [[Arquivos, Properties e script SQL]] |
| O que é `static`/`final`? | `static` = da classe (sem objeto); `final` = não muda / não herda | [[Static, final e classes internas]] |
| O que é `instanceof`? | Testa o tipo do objeto (`campo instanceof JComboBox`) | [[Coleções, generics e instanceof]] |
| Por que `LinkedHashMap`? | Mantém a ordem de inserção dos campos | [[Coleções, generics e instanceof]] |
| O que é `GridLayout`/`BorderLayout`? | Gerenciadores de layout | [[Layouts do Swing]] |
| O que é `javax.swing.Timer`? | Temporizador que roda na thread da interface (fade das telas) | [[Timer, glass pane e fade]] |
| Como gerou o `.jar`? | `build.bat`: `javac`, copia o SQL, junta o driver, `jar cfm` com `Main-Class: Main` | [[Build e jar]] |
| (versão com front-end) O que é `paintComponent`? | Método que o Swing chama para desenhar; sobrescrevemos para pintar | [[Front-end - Java2D e desenho]] |
| (versão com front-end) O que é Nimbus? | Look and Feel do Java; trocamos as cores com `UIManager.put` | [[Front-end - Nimbus, UIManager e renderers]] |
| (versão com front-end) Para que serve a cache de `Capa`? | Não ler o arquivo de imagem a cada repintura | [[Front-end - Imagens, cache e rolagem]] |

## Se não souber
Diga o que o trecho **faz** e **onde está**, e que o conceito foi pesquisado fora da aula. É melhor que chutar. O grupo sabe localizar cada recurso pelo [[Diferenças em relação aos exemplos do professor]].

---
⬅ [[00 - Painel]] · [[Roteiro - versão principal]] · [[Roteiro - versão com front-end]]
