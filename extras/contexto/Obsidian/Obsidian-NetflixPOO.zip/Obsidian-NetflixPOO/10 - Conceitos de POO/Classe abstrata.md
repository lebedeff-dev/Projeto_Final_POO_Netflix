---
tags: [netflix, conceito, poo]
---

# Classe abstrata

**O que é:** Classe que não se instancia e pode ter métodos sem corpo, que as filhas são obrigadas a implementar.

**Onde está no projeto:** `abstract class TelaCrud` tem 4 métodos abstratos: `carregarTabela()`, `inserir()`, `atualizar(String id)` e `eliminar(String id)`. É o padrão Template Method: a base monta o fluxo e as filhas preenchem os "buracos".

Ligações: [[Herança]] · [[Polimorfismo]] · [[TelaCrud]] · [[Conceitos de POO]]
