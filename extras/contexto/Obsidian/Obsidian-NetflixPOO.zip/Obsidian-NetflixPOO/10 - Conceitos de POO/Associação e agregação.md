---
tags: [netflix, conceito, poo]
---

# Associação e agregação

**O que é:** **Associação** liga classes com multiplicidade (1, 0..*). **Agregação** é "tem-um": uma classe contém outra como parte.

**Onde está no projeto:** Plano 1..* Conta, Conta 1..* Perfil, Perfil *..* Título (resolvido pela classe associativa [[Pacote model|HistoricoVisualizacao]]). No código a ligação é a FK. Agregação: [[Telas filhas|TelaPlano]] tem um [[PlanoController]], que tem um [[PlanoDAO]].

Ligações: [[Banco de dados]] · [[Pacote model]] · [[HistoricoVisualizacaoDAO]] · [[Conceitos de POO]]
