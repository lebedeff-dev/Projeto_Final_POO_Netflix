---
tags: [netflix, conceito, poo]
---

# Mensagem

**O que é:** Um objeto (emissor) pede um serviço a outro (receptor) chamando um método. A mensagem tem seletor (nome) e parâmetros; quem sabe **como** fazer é o receptor.

**Onde está no projeto:** `controller.inserir(nome, ...)`: a tela envia, o [[PlanoController]] sabe como validar e gravar. O mesmo vale do controller para o DAO: `dao.inserir(plano)`.

Ligações: [[Classe e objeto]] · [[Pacote controller]] · [[PlanoController]] · [[Conceitos de POO]]
