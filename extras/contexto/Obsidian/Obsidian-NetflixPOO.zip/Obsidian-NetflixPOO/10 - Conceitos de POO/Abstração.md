---
tags: [netflix, conceito, poo]
---

# Abstração

**O que é:** Ficar só com o essencial para a aplicação e ignorar o resto.

**Onde está no projeto:** A Netflix real tem 13 tabelas no modelo do grupo; o sistema usa o recorte de 5 entidades com só os atributos de que precisa.

Ligações: [[Classe e objeto]] · [[Banco de dados]] · [[Visão geral]] · [[Conceitos de POO]]
