---
tags: [netflix, conceito, poo]
---

# Visibilidade

**O que é:** `private`: só a classe; `protected`: a classe e as subclasses; `public`: todos (a interface do objeto).

**Onde está no projeto:** Atributos `private` nos models; `protected` em [[TelaCrud]] (`modelo`, `tabela`, `adicionarCampo`, `valor`) para as telas filhas; métodos `public` nos DAOs e controllers; auxiliares `private` como `montar(...)`.

Ligações: [[Encapsulamento]] · [[Herança]] · [[TelaCrud]] · [[Conceitos de POO]]
