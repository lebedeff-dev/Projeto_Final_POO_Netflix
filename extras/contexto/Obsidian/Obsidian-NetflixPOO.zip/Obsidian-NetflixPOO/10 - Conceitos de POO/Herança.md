---
tags: [netflix, conceito, poo]
---

# Herança

**O que é:** Uma subclasse herda atributos e métodos da superclasse (relação "é-um"). Java só permite herança simples de classes.

**Onde está no projeto:** `TelaPlano extends TelaCrud extends JFrame`. `super(titulo, colunas)` no construtor da filha chama o da [[TelaCrud]], que chama `super(titulo)` do `JFrame`. [[TelaPrincipal]], [[TelaConexao]] e [[TelaRelatorio]] herdam direto de `JFrame`.

Ligações: [[Polimorfismo]] · [[Classe abstrata]] · [[TelaCrud]] · [[Conceitos de POO]]
