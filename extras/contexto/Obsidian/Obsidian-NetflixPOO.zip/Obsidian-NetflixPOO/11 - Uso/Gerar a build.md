---
tags: [netflix, uso, build]
---

# Gerar a build

*Seção 10 da documentação: Como gerar a build (Netflix.jar)*


Só é preciso se alguém **mudar o código**. O jar pronto já está em `Netflix.jar`.

- **Windows:** dois cliques em `Netflix/build.bat`.
- **Linux/macOS:** `bash Netflix/build.sh`.

O que o script faz (cada passo está comentado nele):

1. Lista os `.java` de `src/` em `build/fontes.txt`.
2. Compila com `javac -encoding UTF-8 --release 11 -cp lib/mysql-connector-j-9.3.0.jar -d build/classes @build/fontes.txt` (`--release 11` = roda em qualquer Java 11 ou mais novo).
3. Copia `sql/netflix.sql` para dentro das classes (o [[CriadorBanco]] lê de lá).
4. Extrai o driver do MySQL para dentro (`jar xf`) e apaga o `MANIFEST.MF` e o `INDEX.LIST` dele (senão confundem o nosso jar).
5. Cria o manifesto `Main-Class: Main` e monta o jar: `jar cfm ../Netflix.jar build/manifest.txt -C build/classes .`.

Resultado: um único arquivo (~2,6 MB) com nossas classes, o driver e o script SQL.

---
⬅ [[Conceitos de POO]] · [[00 - Painel]] · [[Rodar e testar]] ➡
