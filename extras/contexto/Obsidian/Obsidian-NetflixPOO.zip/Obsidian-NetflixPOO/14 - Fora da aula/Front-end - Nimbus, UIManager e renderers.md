---
tags: [netflix, fora-da-aula, front-end, nimbus]
---

# Front-end · Nimbus, `UIManager` e renderers

> [!info] Só na versão com front-end
> O professor usa a aparência padrão do NetBeans. Na versão com front-end trocamos para um **tema escuro** ligando o **Nimbus** e substituindo as cores globais.

## `UIManager` e Look and Feel

```java
for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
    if ("Nimbus".equals(info.getName())) {
        UIManager.setLookAndFeel(info.getClassName());
        break;
    }
}
UIManager.put("control", PAINEL);
UIManager.put("text", TEXTO);
UIManager.put("nimbusSelectionBackground", VERMELHO);
```
| Trecho | O que faz |
|---|---|
| **Look and Feel** | A "aparência" de todos os componentes Swing. **Nimbus** é uma já inclusa no Java (moderna) |
| `getInstalledLookAndFeels()` | Lista as aparências instaladas; procuramos a de nome `"Nimbus"` |
| `UIManager.setLookAndFeel(...)` | Liga |
| `UIManager.put("chave", cor)` | Troca uma configuração **global** (ex.: `"text"` muda a cor do texto de todo componente, até do `JOptionPane`) |
| `try/catch (Exception e)` vazio | Se não houver Nimbus o sistema abre com a aparência padrão |
| Chamado em `Main`, **antes** de criar qualquer janela | Senão os componentes já criados ficam com a aparência antiga |

## Fonte que existe no computador

```java
String[] preferidas = {"Segoe UI", "SF Pro Text", "Helvetica Neue", "Ubuntu", "Noto Sans"};
GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()
```
- Pergunta ao sistema quais fontes existem e usa a primeira da lista; senão, `Font.SANS_SERIF`. Assim roda em Windows, Mac e Linux.

## Renderer: "quem desenha a célula"

A `JTable`, o `JComboBox` e a lista **não desenham cada item sozinhos**: pedem a um *renderer*. Trocamos o renderer para pintar do nosso jeito.

```java
tabela.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
    @Override
    public Component getTableCellRendererComponent(JTable t, Object valor, boolean selecionada,
                                                   boolean foco, int linha, int coluna) {
        super.getTableCellRendererComponent(t, valor, selecionada, false, linha, coluna);
        setBackground(selecionada ? VERMELHO : (linha % 2 == 0 ? CAMPO : LINHA_ALTERNADA));
        return this;
    }
});
```
| Trecho | O que faz |
|---|---|
| `new DefaultTableCellRenderer() { ... }` | **Classe anônima** que herda do renderer padrão |
| `getTableCellRendererComponent(...)` | O Swing chama para **cada célula**, passando valor, linha, coluna e se está selecionada |
| `linha % 2 == 0 ? CAMPO : LINHA_ALTERNADA` | **Listras alternadas**: linha par de uma cor, ímpar de outra |
| `selecionada ? VERMELHO : ...` | Linha selecionada em vermelho |
| `return this` | Devolve o próprio renderer já configurado |

O mesmo vale para o `JComboBox` (`DefaultListCellRenderer`) e para o cabeçalho da tabela.

## Outras personalizações de `Tema`

| Item | Técnica |
|---|---|
| Combo escuro | `combo.setUI(new BasicComboBoxUI() { ... })` troca a **classe que desenha** o combo (seta e fundo lisos) |
| Barra de rolagem fina | `class BarraFina extends BasicScrollBarUI` (herança): remove as setas e pinta um "polegar" arredondado |
| Foco do campo | `FocusAdapter` (`focusGained`/`focusLost`) muda a borda para vermelha |
| Larguras das colunas | `FontMetrics.stringWidth` mede o texto e `setPreferredWidth` ajusta cada coluna |

> [!codigo] Como responder
> **"O que é Nimbus?"** — "Uma aparência (Look and Feel) que já vem no Java. Ligamos com `UIManager.setLookAndFeel` e trocamos as cores com `UIManager.put`."
>
> **"O que é um renderer?"** — "O objeto que a tabela chama para desenhar cada célula. Sobrescrevemos para pintar as linhas alternadas e a seleção em vermelho; os dados continuam no `DefaultTableModel`."

---
⬅ [[Fora da aula - Índice]] · [[Tema]] · [[Front-end - Java2D e desenho]]
