---
tags: [netflix, fora-da-aula, sql, banco]
---

# SQL além da aula

> [!info] O que o professor mostrou
> Só `SELECT ... WHERE email=?` e `INSERT ... VALUES(null,?,?,?)` numa tabela `alunos` (arquivo `Persistencia POO mysql.txt`). **JOIN, chave estrangeira, ENUM, DECIMAL, UNIQUE e CASCADE não aparecem.** A proposta, porém, **exige** PK, FK e JOIN.

## INNER JOIN (o mais importante)

```sql
SELECT h.id_visualizacao, h.id_perfil, h.id_titulo, h.data_inicio, ...,
       p.nome AS nome_perfil, t.nome AS nome_titulo,
       c.email AS email_conta, pl.nome AS nome_plano
FROM historico_visualizacao h
INNER JOIN perfil p  ON p.id_perfil = h.id_perfil
INNER JOIN titulo t  ON t.id_titulo = h.id_titulo
INNER JOIN conta  c  ON c.id_conta  = p.id_conta
INNER JOIN plano  pl ON pl.id_plano = c.id_plano
```

| Trecho | Significado |
|---|---|
| `FROM historico_visualizacao h` | Tabela principal; `h` é um **apelido** (alias) para encurtar |
| `INNER JOIN perfil p ON p.id_perfil = h.id_perfil` | "Junte cada visualização com o perfil cujo id é igual". `ON` diz **como casar** as linhas (PK = FK) |
| `INNER` | Só entram linhas que **têm par** nas duas tabelas. Visualização sem perfil não apareceria |
| `p.nome AS nome_perfil` | `perfil`, `titulo` e `plano` têm uma coluna `nome`; o apelido `AS` evita confundir no `ResultSet` |
| Encadeado | perfil → conta → plano: de **quem** é a visualização e em **qual plano** |

Por que existe: a proposta pede mostrar **"Maria Silva"** em vez do código **7**. Ver também [[HistoricoVisualizacaoDAO]].

> [!tip] Onde mais há JOIN
> `ContaDAO.listar()` (conta + plano) e `PerfilDAO.listar()` (perfil + conta). Por isso a tabela de Contas mostra "3 - Premium".

## Chaves primárias e estrangeiras

```sql
id_plano INT AUTO_INCREMENT PRIMARY KEY,
CONSTRAINT fk_conta_plano FOREIGN KEY (id_plano) REFERENCES plano (id_plano)
```
- **PRIMARY KEY:** identifica a linha; não repete e não é nula. **AUTO_INCREMENT:** o MySQL numera sozinho.
- **FOREIGN KEY:** o valor de `conta.id_plano` **tem que existir** em `plano.id_plano`. Isso é o relacionamento. Se não existir, o MySQL recusa (erro 1452).
- Se tentar apagar um plano que tem contas, recusa (erro 1451). Tratamos nos Controllers.

## `ON DELETE CASCADE` (só no histórico)

```sql
CONSTRAINT fk_hist_perfil FOREIGN KEY (id_perfil) REFERENCES perfil (id_perfil) ON DELETE CASCADE
```
- Ao apagar um perfil ou um título, as visualizações dele **somem junto**, para não sobrar histórico apontando para o nada.
- Em plano→conta e conta→perfil **não** usamos cascade: apagar um plano não deve apagar as contas sem o usuário perceber. Por isso a mensagem de bloqueio.

## Tipos e restrições

| Item | Onde | Para que |
|---|---|---|
| `ENUM('SD','HD','Full HD','4K UHD')` | `plano.qualidade_maxima`, `conta.status`, `titulo.tipo`, `dispositivo` | Só aceita os valores da lista; a tela usa um `JComboBox` com os mesmos valores |
| `DECIMAL(6,2)` | `plano.valor_mensal` | Dinheiro exato (2 casas); no Java vira `BigDecimal` |
| `UNIQUE` | `conta.email` | Não deixa duas contas com o mesmo e-mail (erro 1062) |
| `NOT NULL` / `DEFAULT` | vários | Campo obrigatório / valor padrão |
| `TINYINT(1)` | `concluido`, `permite_download` | "booleano" do MySQL (0 ou 1) |
| `TEXT` | `descricao`, `sinopse` | Texto longo |
| `ENGINE=InnoDB` | todas | Motor que suporta chave estrangeira |

## Funções usadas nas consultas

```sql
WHERE DATE(h.data_inicio) BETWEEN ? AND ?
```
- `DATE(...)` tira a **hora** de um `DATETIME`, para comparar só a data.
- `BETWEEN a AND b` inclui as **duas pontas**. Usamos no relatório por período.
- `AND h.id_perfil = ?` entra só se o usuário escolheu um perfil (filtro opcional).

```sql
SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name = 'netflix'
```
- `information_schema` é o "catálogo" do MySQL (lista bancos e tabelas). O `CriadorBanco` pergunta se o banco já existe antes de criar. Ver [[CriadorBanco]].

## O script

`DROP DATABASE IF EXISTS netflix; CREATE DATABASE ...; USE netflix;` no começo: por isso **"Restaurar dados"** apaga tudo e recria. O mesmo script é aberto no Workbench ou rodado pelo sistema.

> [!codigo] Como responder
> **"O que é o INNER JOIN do seu sistema?"** — "Junta o histórico com perfil, título, conta e plano pelas chaves: `p.id_perfil = h.id_perfil` etc. Assim a tela mostra nomes (Ana, Stranger Things, ana.silva@email.com, Premium) e não os números das chaves."
>
> **"Qual a diferença entre PK e FK?"** — "PK identifica a linha na própria tabela. FK é a coluna que guarda a PK de outra tabela e obriga o relacionamento."

---
⬅ [[Fora da aula - Índice]] · [[Banco de dados]] · [[HistoricoVisualizacaoDAO]] · [[Perguntas - Banco de dados]]
