---
tags: [netflix, fora-da-aula, jdbc, dao]
---

# try-with-resources e JDBC além da aula

> [!info] O que o professor mostrou
> `abrirBanco()` guarda `Connection con`, `PreparedStatement ps`, `ResultSet rs` como atributos; `try/catch` com `throws`; `ps.execute()` e `executeQuery()`; `fecharBanco()` fecha só o `ps`. **Nada de `try (...)`, `getGeneratedKeys`, `setNull`, `executeUpdate`.**

## try-with-resources

```java
try (Connection con = ConnectionFactory.getConnection();
     PreparedStatement ps = con.prepareStatement(sql);
     ResultSet rs = ps.executeQuery()) {
    while (rs.next()) { lista.add(montarPlano(rs)); }
}
```

| Trecho | O que faz |
|---|---|
| `try ( ... )` com parênteses | Declara recursos que o Java **fecha sozinho** ao sair do bloco, mesmo se der erro |
| `Connection con = ...` | Abre a conexão com o MySQL |
| `PreparedStatement ps = con.prepareStatement(sql)` | Prepara o SQL (com `?` nos valores) |
| `ResultSet rs = ps.executeQuery()` | Executa o `SELECT` e guarda o resultado (tabela em memória) |
| `while (rs.next())` | Avança uma linha por vez; devolve `false` quando acaba |
| `lista.add(montarPlano(rs))` | Converte a linha em um objeto `Plano` |

- Fecha na **ordem inversa** (`rs`, depois `ps`, depois `con`).
- Sem isso teríamos de escrever `finally { con.close(); }` em todo método. O exemplo do professor não fecha a conexão (só o `ps`): a conexão fica vazando.
- Não há `catch` no DAO: o método tem `throws SQLException` e quem trata é o **Controller**.

## INSERT e o id (`AUTO_INCREMENT`)

A coluna `id_plano` é `AUTO_INCREMENT`: quem escolhe o número é o MySQL. O INSERT não leva o id e o sistema não precisa dele de volta (a tela recarrega a tabela do banco), por isso **não** usamos `RETURN_GENERATED_KEYS` nem `getGeneratedKeys` (existem no JDBC, mas ficaram de fora).
- `executeUpdate()`: para `INSERT`, `UPDATE` e `DELETE` (devolve quantas linhas mudaram). `executeQuery()`: para `SELECT`.
- No UPDATE e no DELETE usamos o número devolvido: `0` linhas = "registro não encontrado" (`Conversor.REGISTRO_NAO_ENCONTRADO`).

## Valores nulos e tipos

```java
ps.setNull(6, Types.INTEGER);          // TituloDAO: duração de série
ps.setBigDecimal(3, p.getValorMensal()); // PlanoDAO
ps.setDate(7, Date.valueOf(p.getDataCriacao())); // LocalDate -> java.sql.Date
ps.setBoolean(6, p.isPermiteDownload());
```
- Série não tem duração: gravamos **NULL** (não 0). `setNull` precisa do tipo SQL (`Types.INTEGER`).
- Ao ler: `rs.getInt` devolve 0 para NULL, então conferimos `rs.wasNull()` ou `getObject`.

## Por que `PreparedStatement` e não `Statement`?

- O `?` recebe o valor **separado do SQL**: evita **SQL injection** (alguém digitar `'; DROP TABLE...` num campo).
- Único lugar com `Statement`: `CriadorBanco.recriarBanco()`, porque executa o **nosso script**, sem valor digitado pelo usuário.

## Erros do MySQL por código

```java
catch (SQLException e) {
    if (e.getErrorCode() == 1062) return "Já existe uma conta com esse e-mail.";
    if (e.getErrorCode() == 1452) return "O plano escolhido não existe mais...";
    if (e.getErrorCode() == 1451) return "Não é possível remover... em uso";
}
```
- `1062`: valor repetido em coluna `UNIQUE` (e-mail). `1452`: FK aponta para um registro que não existe. `1451`: não dá para apagar o "pai" porque há "filhos" (FK). Assim o usuário lê uma frase clara, em vez do texto técnico do MySQL.

## `try / finally` na tela

Em `TelaCrud.recarregar` há `recarregandoTabela = true; try { ... } finally { recarregandoTabela = false; }`. O `finally` **sempre** roda, mesmo com erro, para a trava não ficar ligada para sempre.

> [!codigo] Como responder
> **"O que é esse `try (...)`?"** — "É o try-with-resources: a conexão, o `PreparedStatement` e o `ResultSet` são fechados automaticamente no fim do bloco, mesmo se acontecer erro. No exemplo da aula o fechamento era manual."
>
> **"Por que o DAO só tem `throws SQLException` e não `catch`?"** — "Porque o DAO não decide o que mostrar ao usuário. O erro sobe para o Controller, que traduz em mensagem."

---
⬅ [[Fora da aula - Índice]] · [[Conceitos de DAO e JDBC]] · [[PlanoDAO]] · [[Integração Java-MySQL]]
