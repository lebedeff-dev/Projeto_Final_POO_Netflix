---
tags: [netflix, fora-da-aula, swing, componentes]
---

# Componentes Swing extras

> [!info] O que o professor mostrou
> `JFrame`, `JLabel`, `JTextField`, `JButton`, `JMenu/JMenuItem`, `JRadioButton`, `JTable`, `DefaultTableModel`, `JScrollPane`, `JOptionPane` (mensagem simples). **O resto abaixo é nosso.**

## Tabela de componentes

| Componente | O que é | Onde |
|---|---|---|
| **`JPanel`** | Caixa para agrupar componentes; cada painel tem seu layout | em todas as telas |
| **`JComboBox<String>`** | Lista suspensa (escolher uma opção) | FKs (Plano, Conta, Perfil, Título), status, tipo |
| **`JPasswordField`** | Campo de senha (mostra pontinhos); `getPassword()` devolve `char[]` | `TelaConexao` |
| **`JFileChooser`** | Janela "Salvar como" do sistema | `TelaRelatorio` (botão Salvar .txt) |
| **`BorderFactory`** | Cria bordas e margens (`createEmptyBorder(top, left, bottom, right)`) | espaçamento das telas |
| **`ListSelectionModel`** | Modo de seleção da tabela | `TelaCrud`: `SINGLE_SELECTION` (1 linha por vez) |
| **`SwingUtilities.invokeLater`** | Executa na thread da interface | `Main` |
| **`JOptionPane.showConfirmDialog`** | Pergunta Sim/Não | confirmar eliminar e restaurar dados |

## `JComboBox` de chave estrangeira

```java
preencherCombo(comboPerfil, controller.opcoesPerfis());   // ["1 - Ana", "2 - Pedro", ...]
...
int idTitulo = Conversor.extrairId(titulo, "Título");     // "3 - Our Planet" -> 3
```
- O combo mostra `id - nome`; o Controller pega só o número antes do ` - ` (`opcao.split(" - ")[0]`).
- A tabela mostra o **mesmo** texto, então ao clicar numa linha basta `combo.setSelectedItem("3 - Premium")` e ele se posiciona sozinho.

## `JPasswordField`

```java
new String(campoSenha.getPassword())
```
- `getPassword()` devolve `char[]` (vetor de caracteres) por segurança (pode ser apagado da memória); `new String(...)` converte em texto.

## `JTable` e `DefaultTableModel` (usados de forma mais completa)

```java
modelo = new DefaultTableModel(colunas, 0) {
    @Override public boolean isCellEditable(int linha, int coluna) { return false; }
};
modelo.setRowCount(0);                 // apaga as linhas
modelo.addRow(new Object[]{...});      // cada posição = uma coluna
tabela.getSelectedRow();               // -1 se nada selecionado
modelo.getValueAt(linha, 0);           // célula
```
- Classe anônima que **sobrescreve** `isCellEditable` para a tabela ser só de leitura (editar é pelo formulário).
- A tabela só **desenha** o modelo: para mudar a tela, mudamos o modelo.

## `SwingUtilities.invokeLater`

```java
SwingUtilities.invokeLater(() -> new TelaConexao().setVisible(true));
```
- O Swing só deve ser mexido pela **Event Dispatch Thread**. `invokeLater` agenda a criação da primeira janela nela. (O NetBeans gera o mesmo: `java.awt.EventQueue.invokeLater`.)

## `JOptionPane` além da mensagem

- `showMessageDialog(this, texto)`: só informa (o professor usa).
- `showConfirmDialog(this, "Remover...?", "Confirmação", YES_NO_OPTION)`: devolve o botão clicado; comparamos com `JOptionPane.YES_OPTION`.
- Diferença para o exemplo: o professor chama `JOptionPane` **dentro do DAO**; nós só na View.

> [!codigo] Como responder
> **"Como o combo sabe qual chave estrangeira gravar?"** — "O texto do combo é `id - nome`. O Controller extrai o número antes do ` - ` e grava esse id na FK."

---
⬅ [[Fora da aula - Índice]] · [[Conceitos de Swing]] · [[TelaCrud]] · [[TelaConexao]]
