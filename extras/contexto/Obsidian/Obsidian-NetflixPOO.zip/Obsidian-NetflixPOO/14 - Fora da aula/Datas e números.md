---
tags: [netflix, fora-da-aula, util, datas]
---

# Datas e números (`LocalDate`, `LocalDateTime`, `BigDecimal`)

> [!info] O que o professor mostrou
> `int` e `String` (idade, nome, e-mail). **Nenhum exemplo usa data ou valor em dinheiro.** Nosso banco tem `DATE`, `DATETIME` e `DECIMAL`, então foi preciso usar as classes abaixo.

## Datas: quem escreve e quem mostra

Só o **Relatório** pede data digitada (`dd/mm/aaaa`). Todas as outras datas (cadastro de plano, conta, perfil e título; início e última visualização do histórico) **são gravadas pelo próprio MySQL** (`CURDATE()` / `NOW()` dentro do INSERT/UPDATE), então o Java nem as recebe.

```
texto "01/06/2025"  --Conversor.paraData-->  LocalDate  --Date.valueOf-->  java.sql.Date  --ps.setDate-->  BETWEEN do relatório
DATETIME do banco   --rs.getTimestamp().toLocalDateTime()-->  LocalDateTime  --Conversor.formatarDataHora-->  "01/06/2025 20:00" na tabela
```

| Tipo | O que guarda | Onde |
|---|---|---|
| `LocalDate` | só a data | filtro do relatório |
| `LocalDateTime` | data + hora | `historico.data_inicio`, `data_ultima_visualizacao` (só leitura/exibição) |
| `java.sql.Date` / `Timestamp` | os mesmos, no formato que o JDBC entende | só dentro dos DAOs |

```java
private static final DateTimeFormatter DATA = DateTimeFormatter.ofPattern("dd/MM/uuuu")
        .withResolverStyle(ResolverStyle.STRICT);

public static LocalDate paraData(String texto, String campo) {
    try {
        return LocalDate.parse(obrigatorio(texto, campo), DATA);
    } catch (DateTimeParseException e) {
        throw new IllegalArgumentException("O campo '" + campo + "' deve ser uma data válida no formato dd/mm/aaaa (ex.: 31/12/2026).");
    }
}
```
| Trecho | O que faz |
|---|---|
| `DateTimeFormatter.ofPattern("dd/MM/uuuu")` | Define o formato: dia/mês/ano (`MM` = mês, `mm` = minuto) |
| `ResolverStyle.STRICT` | Recusa datas que não existem (31/02) |
| `LocalDate.parse(texto, formato)` | Converte o texto em objeto; se estiver errado lança `DateTimeParseException` |
| `catch ... throw new IllegalArgumentException(...)` | Troca o erro técnico por uma mensagem clara para o usuário |
| `LocalDate.now()` | Data de hoje (`Conversor.hoje()`, padrão da data final do relatório) |
| `dataHora.format(DATA_HORA)` | Objeto → texto `dd/MM/yyyy HH:mm` para a tabela |

- No DAO: `... VALUES (?, ?, NOW(), NOW(), ?, ?, ?)` no INSERT do histórico e `data_ultima_visualizacao = NOW()` no UPDATE; ao ler, `rs.getTimestamp("data_inicio").toLocalDateTime()`.
- **Por que `LocalDate` e não `Date`/`SimpleDateFormat`?** São as classes modernas (Java 8+): imutáveis e sem problema de fuso nas contas.

### Fuso horário (detalhe que já deu bug)
Na `ConnectionFactory`: `connectionTimeZone=LOCAL`. Sem isso, o driver usava um fuso fixo e o horário aparecia deslocado (20:00 virava 23:00 em outro computador). Ver [[ConnectionFactory]].

## Dinheiro: `BigDecimal`

```java
private BigDecimal valorMensal;        // Plano.java
public static BigDecimal paraDecimal(String texto, String campo) {
    return new BigDecimal(obrigatorio(texto, campo).replace(',', '.'));
}
ps.setBigDecimal(3, p.getValorMensal());
```
- `double` erra arredondamento (`0.1 + 0.2` = `0.30000000000000004`). Em dinheiro isso não pode acontecer, então usamos `BigDecimal`, que é **exato**, e `DECIMAL(6,2)` no banco.
- `.replace(',', '.')`: aceita "39,90" e "39.90".
- Regra no `PlanoController`: `valor.signum() <= 0` (sinal do número) recusa valor zero ou negativo.

## Números de formulário

`Conversor.paraInt` usa `Integer.parseInt` dentro de `try/catch (NumberFormatException)`. Todo valor da tela chega como `String`; quem converte e valida é o Controller (via `Conversor`).

> [!codigo] Como responder
> **"Por que `BigDecimal` no valor do plano?"** — "Porque `double` tem erro de arredondamento e é impróprio para dinheiro. `BigDecimal` é exato e combina com o `DECIMAL(6,2)` do MySQL."
>
> **"Como a data digitada vira data do banco?"** — "Só o relatório pede data: o `Conversor` lê o texto com `LocalDate.parse` e um formato brasileiro; o DAO converte para `Date.valueOf` e usa no `BETWEEN`. As demais datas o MySQL grava sozinho com `NOW()`/`CURDATE()`."

---
⬅ [[Fora da aula - Índice]] · [[Conversor]] · [[Pacote model]] · [[Validação com exceções]]
