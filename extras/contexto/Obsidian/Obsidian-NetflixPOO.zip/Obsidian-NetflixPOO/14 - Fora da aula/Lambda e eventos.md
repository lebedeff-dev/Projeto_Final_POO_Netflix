---
tags: [netflix, fora-da-aula, swing, eventos]
---

# Lambda e eventos (`e -> ...`)

> [!info] O que o professor mostrou
> O NetBeans gera o evento do botão assim (classe anônima com `ActionListener`). **Lambda (`->`) não aparece em nenhum exemplo.**

## A mesma coisa, dos dois jeitos

```java
// Como o NetBeans gera (material do professor)
btnInserir.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        mostrarResultado(inserir());
    }
});

// Como escrevemos (lambda)
btnInserir.addActionListener(e -> mostrarResultado(inserir()));
```

## Linha a linha

| Trecho | O que faz |
|---|---|
| `btnInserir.addActionListener(...)` | Registra **o que fazer quando o botão for clicado** |
| `e` | O evento (`ActionEvent`). Quase nunca usamos, mas o nome é obrigatório |
| `->` | "faça isto". Separa o parâmetro do corpo |
| `mostrarResultado(inserir())` | O corpo: chama o método da tela filha e mostra a mensagem |

- Lambda só funciona quando a interface tem **um único método** (aqui `actionPerformed`). Por isso serve para `ActionListener`.
- Corpo com mais de uma linha vai entre chaves `{ ... }` (usamos em `recarregar` e no listener da tabela).

## Onde usamos

- **Todas as telas:** `e -> mostrarResultado(inserir())`, `e -> confirmarEliminar()`, `e -> limpar()`.
- **`TelaPrincipal`:** `e -> Navegador.ir(this, new TelaPlano())` (um por botão do menu).
- **`BarraNavegacao`:** um lambda por botão da barra.
- **`Main`:** `SwingUtilities.invokeLater(() -> new TelaConexao().setVisible(true))`. Aqui o lambda **não tem parâmetro** (`()`), porque `Runnable.run()` não recebe nada.

## Outros tipos de evento (não vistos em aula)

| Evento | Onde | Para quê |
|---|---|---|
| `ListSelectionListener` (lambda) | `TelaCrud` | Ao clicar numa linha da tabela, copia os valores para o formulário |
| `MouseAdapter`, `KeyAdapter`, `FocusAdapter` (versão com front-end) | `Visoes`, `Tema` | Hover, teclado e foco nos desenhos e campos |

> [!codigo] Como responder
> **"O que é esse `e -> ...`?"** — "É uma expressão lambda: forma curta de criar o `ActionListener`. É o mesmo que a classe anônima que o NetBeans gera, só que mais enxuta. O `e` é o evento do clique."
>
> **"Por que o clique não tem lógica?"** — "Porque a proposta não aceita lógica no botão. Ele só chama o método da tela, que chama o Controller."

---
⬅ [[Fora da aula - Índice]] · [[Conceitos de Swing]] · [[TelaCrud]]
