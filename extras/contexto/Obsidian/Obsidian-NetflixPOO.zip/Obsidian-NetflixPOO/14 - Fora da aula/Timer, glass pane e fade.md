---
tags: [netflix, fora-da-aula, swing, animacao]
---

# `Timer`, glass pane e o fade-in (`Navegador`)

> [!info] O que o professor mostrou
> Nada de animação, `Timer` ou desenho próprio. **Está nas duas versões** (versão principal e versão com front-end): é a transição suave entre telas.

## O problema

Antes, cada botão abria **outra janela por cima**: ficavam janelas empilhadas. Queríamos **uma janela por vez**, com uma entrada suave.

## Por que não `Window.setOpacity`?

`setOpacity` mudaria a transparência da janela inteira, mas **lança `IllegalComponentStateException`** em janela com a barra de título do Windows ("The frame is decorated"). Testamos. Solução: fazer o fade **dentro** da janela.

## Como funciona: o "véu"

```java
Veu veu = new Veu(nova.getContentPane().getBackground()); // cor do fundo da tela
nova.setGlassPane(veu);
veu.setVisible(true);
nova.setVisible(true);

Timer relogio = new Timer(16, null);
relogio.addActionListener(e -> {
    veu.alfa -= 0.11f;
    if (veu.alfa <= 0f) { relogio.stop(); veu.setVisible(false); }
    veu.repaint();
});
relogio.start();
```

| Peça | O que é |
|---|---|
| **Glass pane** | Uma camada **transparente por cima** de todo o conteúdo da janela (`JFrame.setGlassPane`). Quando visível, cobre a tela e também **bloqueia cliques** |
| **`Veu`** (classe interna) | Um `JPanel` que pinta um retângulo da **cor de fundo** com um `alfa` (opacidade) |
| **`alfa`** | De `1.0` (cobre tudo, a tela parece vazia) até `0.0` (some). Cai `0.11` por passo → **9 passos** |
| **`javax.swing.Timer(16, ...)`** | Dispara o `ActionListener` **a cada 16 ms** (~60 quadros/s) na **thread da interface** |
| `relogio.stop()` e `veu.setVisible(false)` | No fim, para o timer e **tira o véu**: a tela volta a receber cliques |

Total: 9 × 16 ms ≈ **150 ms**, curto de propósito (telas de trabalho são usadas muitas vezes).

## Por que `javax.swing.Timer` e não uma `Thread`?

O `Timer` do Swing chama o código **na Event Dispatch Thread**, então é seguro mexer em componentes. Uma `Thread` comum mexendo em componente pode travar ou desenhar errado.

## Pintar com transparência

```java
g2.setColor(new Color(r, g, b, (int) (alfa * 255)));   // o 4º valor é o alfa (0-255)
g2.fillRect(0, 0, getWidth(), getHeight());
```
- `Color(r, g, b, alfa)`: o último número é a opacidade. `paintComponent` desenha; `setOpaque(false)` deixa o painel transparente fora do que pintamos.

## `Navegador.ir` e `Navegador.trocar`

| Método | Faz | Quando |
|---|---|---|
| `ir(atual, nova)` | `nova.setBounds(atual.getBounds())` (mesmo lugar e tamanho), copia o estado maximizada/normal, mostra com fade e **`atual.dispose()`** | Botões da barra e do menu |
| `trocar(origem, nova)` | Centraliza a nova na tela, mostra com fade e fecha a origem | Só na **versão principal**, da tela de conexão para o menu (na versão com front-end a conexão fecha e abre o Início sem fade) |

`dispose()` fecha **só aquela janela** (libera os recursos). Como só existe uma janela por vez, `EXIT_ON_CLOSE` em todas: fechar no X encerra o programa.

> [!codigo] Como responder
> **"Como fez a transição?"** — "Mostramos a tela nova no mesmo lugar da antiga e colocamos por cima um painel transparente (glass pane) com a cor de fundo. Um `javax.swing.Timer` a cada 16 ms diminui a opacidade desse painel até sumir. Depois escondemos o painel e fechamos a janela antiga."
>
> **"Por que não usou `setOpacity`?"** — "Não funciona em janela decorada do Windows: lança exceção."

---
⬅ [[Fora da aula - Índice]] · [[Navegação e transição]] · [[Navegador]] · [[BarraNavegacao]]
