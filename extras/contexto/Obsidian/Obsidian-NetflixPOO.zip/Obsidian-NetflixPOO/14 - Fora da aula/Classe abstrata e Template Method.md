---
tags: [netflix, fora-da-aula, poo, view]
---

# Classe abstrata e Template Method (`TelaCrud`)

> [!info] O que o professor mostrou
> Herança com `extends` e polimorfismo. Num slide aparece `abstract class Funcionario` com um método polimórfico, **mas nenhum dos projetos de exemplo usa `abstract`**. Aqui usamos de verdade.

## O que é

- **Classe abstrata:** classe que **não pode ser instanciada** (`new TelaCrud()` não compila). Ela serve de molde para as filhas.
- **Método abstrato:** método **sem corpo** que a filha é **obrigada** a escrever. Quem não escrever não compila.
- **Template Method:** padrão em que a classe-mãe define o **esqueleto** do algoritmo (monta a tela, liga os botões, recarrega a tabela) e deixa **"buracos"** (os métodos abstratos) para cada filha preencher.

## Onde usamos

`TelaCrud` (mãe) → `TelaPlano`, `TelaConta`, `TelaPerfil`, `TelaTitulo`, `TelaHistorico` (filhas). A mãe tem **~290 linhas** de layout e fluxo; cada filha tem ~60 linhas.

## Linha a linha: a mãe

```java
public abstract class TelaCrud extends JFrame {
```
- `abstract`: ninguém cria uma `TelaCrud` solta; só as filhas.
- `extends JFrame`: toda tela de cadastro **é uma** janela (herança).

```java
protected abstract void carregarTabela();
protected abstract String inserir();
protected abstract String atualizar(String id);
protected abstract String eliminar(String id);
```
- Os quatro "buracos". Sem corpo e terminados em `;`.
- `protected`: visível na própria classe, nas **filhas** e no mesmo pacote. Não é `public` porque ninguém de fora deve chamá-los.
- `inserir()` devolve `String`: a **mensagem** do Controller ("Plano inserido com sucesso!").

```java
protected void carregarCombos() { }
protected void definirPadroes() { }
```
- **Ganchos opcionais** (*hooks*): têm corpo vazio. A filha só sobrescreve se precisar (ex.: `TelaConta` preenche o combo de planos).

```java
protected void iniciar() { ... }
```
- É o **esqueleto**: cria os botões, liga os eventos, monta o layout, define o tamanho e carrega os dados. Cada filha chama `iniciar()` **no fim do seu construtor** (depois de criar os campos). Se a mãe fizesse isso no próprio construtor, os atributos da filha (como o `controller`) ainda seriam `null`.

## Linha a linha: uma filha (`TelaPlano`)

```java
public class TelaPlano extends TelaCrud {
    public TelaPlano() {
        super("Planos", new String[]{"ID", "Nome", ...});
        adicionarCampo("Nome", new JTextField());
        ...
        iniciar();
    }
    @Override
    protected void carregarTabela() { ... }
```
- `super("Planos", colunas)`: chama o construtor da mãe passando o título da janela e os nomes das colunas. **Tem que ser a primeira linha.**
- `adicionarCampo(...)`: cada campo vira um par rótulo + componente no formulário.
- `@Override`: avisa o compilador "este método sobrescreve o da mãe". Se errar o nome, **dá erro** em vez de criar um método novo por engano.

## Polimorfismo aqui

A mãe chama `inserir()` sem saber qual filha está aberta:
```java
btnInserir.addActionListener(e -> mostrarResultado(inserir()));
```
Em tempo de execução, roda o `inserir()` **da tela que estiver aberta** (late binding). É exatamente o polimorfismo do slide, com objetos de telas em vez de funcionários. Veja [[Polimorfismo]], [[Late binding]] e [[Sobrescrita e sobrecarga]].

> [!codigo] Como responder
> **"Por que `TelaCrud` é abstrata?"** — "Porque ela não é uma tela completa: tem o layout e o fluxo comuns, mas não sabe qual controller chamar nem quais colunas mostrar. Isso cada filha define nos métodos abstratos. Assim escrevemos o layout uma vez só e as cinco telas o reaproveitam."
>
> **"O que é o `@Override`?"** — "Indica que o método reescreve um da classe-mãe; o compilador confere se o nome e os parâmetros batem."
>
> **"O que é `protected`?"** — "Acesso permitido na própria classe, nas filhas e no mesmo pacote (slide de visibilidade)."

---
⬅ [[Fora da aula - Índice]] · [[TelaCrud]] · [[Telas filhas]] · [[Classe abstrata]] · [[Herança]]
