---
tags: [netflix, claude, contexto]
---

> Cópia do `CLAUDE.md` da raiz do projeto (o original não vai para o Git).
> Para continuar em outro chat: anexe ou cole esta nota no começo da conversa.

# Projeto Final POO (Netflix) – contexto para o Claude

> [!decisao] Atualizações depois desta nota (30/10/2026)
> - No GitHub a pasta `versão principal` passou a se chamar **`Projeto`** (commit `bce8c8c`). No PC do Guilherme a pasta local continua `versão principal`.
> - **Descrição do plano automática:** `PlanoController.gerarDescricao(telas, qualidade)`; a `TelaPlano` mostra ao vivo em campo somente leitura. Plano exige pelo menos 1 tela.
> - **Testes contra MySQL de verdade** (instância descartável): 79 verificações passaram (conexão, CRUDs, regras, JOIN, CASCADE, relatório, restaurar, tela de planos). A interface (cliques) ainda não foi testada pelo grupo.
> - A senha do `root` do MySQL do Guilherme foi redefinida por ele (não registrada aqui).
> - Este vault passou a se chamar **Obsidian-NetflixPOO** e foi reorganizado no estilo do vault do datathon (pastas numeradas, Painel, cores). Só existe localmente; no GitHub ainda está como `Projeto/Obsidian`.


> Este arquivo NÃO vai para o GitHub (está no `.gitignore`). Serve para continuar o trabalho em outra sessão.

## O que é
Trabalho da disciplina de POO (Católica de Brasília): sistema desktop Java Swing + MySQL + JDBC + MVC.
A proposta está em `versão principal/Proposta/Trabalho Pratico  POO Final.pdf`. Exigências: 4 CRUDs simples completos +
1 CRUD principal (com FKs) + 1 consulta com JOIN + 1 relatório da rotina principal + POO + MVC + script SQL.
Cada aluno responde 2 perguntas sobre o código na apresentação, então o código precisa ser SIMPLES de explicar.

## Pastas
- `primeira versão (reprovada)/` – primeira versão (não vai para o Git). Tinha tudo menos um relatório de verdade; não tinha build;
  configurar o banco era confuso (abrir Workbench, editar senha no código, recompilar).
- `versão principal/` – versão atual (a única que vai para o Git).
  - `Netflix.jar` + `Abrir Netflix.bat` – build pronta para o grupo.
  - `Netflix/` – código-fonte (`src/`, `sql/netflix.sql`, `lib/` com o driver, `build.bat`/`build.sh`).
  - `DOCUMENTACAO.md` – documentação completa (mesmo estilo da primeira versão, atualizada).
  - `Banco de dados/`, `Fontes/`, `Proposta/` – copiadas da primeira versão a pedido do usuário.
- `README.md` (raiz) – explicação para o grupo (como rodar, estrutura, requisitos).

## Pedidos do usuário nesta sessão (2026-10-30)
1. Revisar a primeira versão contra a proposta → faltava o **relatório** da rotina principal (feito na versão principal: TelaRelatorio).
2. Recodar para ter uma **build** que o grupo consiga abrir → `Netflix.jar` (precisa Java 11+ e MySQL Server).
3. Código simples de explicar + documentação explicando tudo, igual à primeira versão mas atualizada → `versão principal/DOCUMENTACAO.md`.
4. Tudo numa pasta `versão principal`, separado por versões.
5. Sugerir outras melhorias antes de fazer. O usuário não respondeu às opções; foram aplicadas as recomendadas:
   - banco criado automaticamente na 1ª execução + botão "Restaurar dados de exemplo";
   - tela de conexão (usuário/senha do MySQL salvos em `config.properties` ao lado do jar, sem recompilar);
   - Java simplificado (sem Supplier/method reference/colunas escondidas; FKs mostradas como "3 - Premium"; combos recarregam);
   - NÃO enxugou as tabelas (mantido o modelo da primeira versão, que o usuário gostou).
6. Commit/push em https://github.com/lebedeff-dev/Projeto_Final_POO_Netflix **somente da versão principal** (+ README e .gitignore na raiz),
   com autor **Guilherme Lebedeff <guilebedev@gmail.com>** e **sem** linha de coautoria do Claude.
7. Copiar `Fontes`, `Banco de dados` e `Proposta` da primeira versão para a versão principal (e commitar junto).
8. Este `CLAUDE.md` fica fora do commit.

## Estado ao fim da sessão de 2026-10-30
- Commit `8ea49db` enviado para `origin/main` (repo inicializado na raiz "Projeto Final POO"; identidade git configurada só localmente).
- `Netflix.jar` compilado com JDK 17 (`--release 11`) e conferido: script SQL embutido divide em 13 comandos, driver registra.
- **NÃO testado contra o MySQL** (a senha do root desta máquina não é conhecida pelo Claude). Pendente: abrir o jar,
  conectar com a senha real e seguir o roteiro da seção 11 da DOCUMENTACAO.md.
- Atenção: se já existir um banco `netflix` da primeira versão no MySQL, a versão principal o reaproveita (mesmo modelo); "Restaurar dados de exemplo" recria.

## Pedido seguinte (mesma data): vault do Obsidian
- `versão principal/DOCUMENTACAO.md` transformado em vault do Obsidian em `versão principal/Obsidian/` (o .md original continua na pasta).
  Uma nota por classe/tópico, ligadas por `[[links]]`, índice em `00 Início.md`, diagramas Mermaid.
- O vault é GERADO por `versão principal/Obsidian/_gerar_vault.py` a partir do DOCUMENTACAO.md: ao mudar a documentação,
  edite o DOCUMENTACAO.md e rode `python versão principal/Obsidian/_gerar_vault.py` (recria as notas; não toca em `.obsidian/`).
- Uma cópia deste CLAUDE.md vai no vault (`CLAUDE - contexto da sessão.md`) e FOI commitada, a pedido do usuário
  ("inclua o claude md no obsidian"). O CLAUDE.md da raiz continua fora do Git.

## Convenções
- Textos, comentários e documentação em português.
- Commits: autor Guilherme Lebedeff, sem "Co-Authored-By: Claude".
- Ao mudar o código, gerar o jar de novo com `Netflix/build.bat` e atualizar `DOCUMENTACAO.md`.

---
[[00 - Painel]]
