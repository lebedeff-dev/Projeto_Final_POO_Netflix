---
tags: [netflix, codigo, controller, classe]
---

# ConexaoController

*Seção 6.5: ConexaoController (novo)* · Pasta: [[Pacote controller]]


- Construtor: [[ConnectionFactory]]`.carregarConfiguracao();` lê o `config.properties` para a tela já abrir preenchida, **só na primeira vez** (trava `configuracaoCarregada`). O menu também cria um `ConexaoController`; sem a trava ele releria o arquivo e poderia trocar a senha recém-digitada por uma antiga. `servidorSalvo()`, `portaSalva()`, `usuarioSalvo()`, `senhaSalva()` entregam esses valores à tela.
- `conectar(servidor, porta, usuario, senha)`:
  1. valida (`obrigatorio`, `paraInt`) e chama [[ConnectionFactory]]`.configurar(...)`;
  2. [[CriadorBanco]]`.criarSeNaoExistir();`: na primeira vez cria o banco com os dados de exemplo (isso também **testa** a conexão);
  3. [[ConnectionFactory]]`.salvarConfiguracao();` dentro de um `try`: se a pasta não permitir gravar, **não bloqueia o login**; o sistema abre e `getAviso()` devolve um aviso que a [[TelaConexao]] mostra ("não foi possível salvar a configuração... será preciso digitar a senha de novo");
  4. `return null;`: **null significa "deu certo"**; qualquer texto é a mensagem de erro. Erro de `SQLException` vira "Não foi possível conectar ao MySQL. Confira se ele está ligado e se o usuário/senha estão certos."
- `restaurarDadosExemplo()`: [[CriadorBanco]]`.recriarBanco()` e mensagem de sucesso/erro.

---
⬅ [[RelatorioController]] · [[00 - Painel]] · [[Pacote view]] ➡
