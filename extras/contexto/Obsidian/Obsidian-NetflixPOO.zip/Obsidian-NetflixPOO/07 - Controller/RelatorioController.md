---
tags: [netflix, codigo, controller, classe]
---

# RelatorioController

*Seção 6.4: RelatorioController (novo: relatório da rotina principal)* · Pasta: [[Pacote controller]]


- `public static final String TODOS = "Todos";`: texto da opção "todos os perfis" (constante para não digitar a mesma string em dois lugares).
- `opcoesPerfis()`: lista com `"Todos"` + `"id - nome"` de cada perfil.
- `gerar(String dataInicial, String dataFinal, String perfil)`:
  - converte as duas datas com [[Conversor]]`.paraData`;
  - **regra:** `if (fim.isBefore(inicio))` → "A data final não pode ser anterior à data inicial.";
  - `int idPerfil = TODOS.equals(perfil) ? 0 : Conversor.extrairId(perfil, "Perfil");`: 0 significa "todos";
  - `return dao.listarPorPeriodo(inicio, fim, idPerfil);` (SQLException vira RuntimeException, como nos `listar`).
- `resumo(List<HistoricoVisualizacao> lista)`: **calcula os totais** percorrendo a lista: `if (h.isConcluido()) { concluidas++; }` e `minutos += h.getMinutoParada();`. Devolve "Total de visualizações: 6 | Concluídas: 3 | Em andamento: 3 | Minutos assistidos: 422". Fica no Controller porque é regra de negócio, não desenho de tela.
- `salvarTxt(caminho, lista, ...)`: monta o texto do relatório com `StringBuilder` (junta pedaços de texto de forma eficiente) e grava com `Files.write(Path.of(caminho), texto.getBytes(UTF_8))`. Devolve a mensagem de sucesso ou de erro (`IOException`).

---
⬅ [[HistoricoController]] · [[00 - Painel]] · [[ConexaoController]] ➡
