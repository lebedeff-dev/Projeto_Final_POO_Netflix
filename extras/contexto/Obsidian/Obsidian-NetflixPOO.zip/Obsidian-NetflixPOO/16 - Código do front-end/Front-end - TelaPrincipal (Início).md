---
tags: [netflix, front-end, codigo, inicio]
---

# Front-end · `TelaPrincipal` (tela Início)

> [!info] O que mostra
> Barra do topo + **destaque** (um título grande) + fileira **"Populares na Netflix"** (todos os títulos) + fileira **"Continuar assistindo como <perfil>"** (o que o perfil mais recente assistiu, com barra de progresso). Na versão principal a `TelaPrincipal` é um menu simples com botões; a lógica é a mesma (só **lê** dos Controllers).

## Estrutura

| Membro | Faz |
|---|---|
| `conexaoController` | Usado só para **Restaurar dados** |
| `titulos`, `historico` (`List`) | Dados lidos dos Controllers |
| `destaque` (`Destaque`) | O banner do topo; muda quando se clica numa capa |
| `rolagemPrincipal` | Para voltar ao topo quando o destaque muda |
| Construtor | `carregarDados()` → `montarTela()` → tamanho (`Math.min`) → `EXIT_ON_CLOSE` |

## Métodos

| Método | O que faz |
|---|---|
| `carregarDados()` | `new TituloController().listar()` e `new HistoricoController().listarComNomes()` dentro de `try/catch (RuntimeException)`: se o banco falhar, as listas ficam vazias (a tela abre mesmo assim) |
| `montarTela()` | Raiz `BorderLayout`: `criarBarraSuperior()` no NORTH e o conteúdo rolável no CENTER. **Também é chamado depois de restaurar** para redesenhar |
| `criarBarraSuperior()` | `new BarraNavegacao(this, "Início", restaurar)` com o botão "Restaurar dados" no canto direito |
| `restaurar()` | `showConfirmDialog` → se `YES_OPTION`: `conexaoController.restaurarDadosExemplo()`, `carregarDados()`, `montarTela()`, `revalidate()`, `repaint()` |
| `criarConteudo()` | `BoxLayout(Y_AXIS)`: destaque + fileiras |
| `fileira(titulo, capas)` | Rótulo + capas lado a lado, com `Tema.rolagemHorizontal` |

### A fileira "Populares"
- Um `CartaDeCapa` por título. Ao clicar: `destaque.mostrar(t)`, marca a capa escolhida (`setEscolhida`) e sobe a rolagem com `SwingUtilities.invokeLater(... setViewPosition(new Point(0,0)))`.
- `invokeLater`: executa **depois** que o Swing termina o que está fazendo (o layout ainda estava mudando).

### A fileira "Continuar assistindo"
```java
HistoricoVisualizacao ultimo = null;
for (HistoricoVisualizacao h : historico)
    if (ultimo == null || h.getDataUltimaVisualizacao().isAfter(ultimo.getDataUltimaVisualizacao())) ultimo = h;
```
- **Algoritmo do maior**: percorre e guarda o registro com a data de última visualização mais recente (`isAfter` de `LocalDateTime`).
- `Map<Integer, Titulo> porId = new HashMap<>()`: busca rápida do título pelo ID (para saber a duração).
- Só entram os registros do **mesmo perfil** do último (`h.getIdPerfil() != ultimo.getIdPerfil()` → `continue`).
- **Progresso:** `concluido ? 1.0 : (minutoParada / duracao)`, limitado a 1.0 por `Math.min`. Série (sem duração) mostra `0.33`.
- Clique numa dessas capas abre o Histórico (`abrirHistorico()` → `Navegador.ir`).

## Classes internas

### `CartaDeCapa extends JButton`
`paintComponent` desenha, nesta ordem: a capa (`Capa.desenhar`), a **barra de progresso** (retângulo preto transparente + retângulo vermelho de largura `w * progresso`), o **contorno** branco (hover/foco/escolhida) e o texto (nome em negrito e linha de apoio em cinza, cortados por `cortar` com "…").
- `super(nome)`: o texto do botão é o nome (leitores de tela).
- `setToolTipText(nome)`: balãozinho ao parar o mouse.

### `Destaque extends JPanel`
- Rótulos: "EM DESTAQUE", nome (46 pt), meta (classificação • ano • tipo • idioma, em **verde**), sinopse (`<html><body style='width:440px'>...</body></html>` → o `JLabel` quebra linhas com HTML) e dois botões (`Ver títulos`, `Ver histórico`).
- `BoxLayout` empilha os rótulos na vertical; `Box.createVerticalStrut(10)` = espaço fixo.
- `mostrar(Titulo novo)`: troca textos e `repaint()`.
- `paintComponent`: (1) capa esticada na metade direita escurecida; (2) dois `GradientPaint` (some para a esquerda e para baixo); (3) a capa inteira com proporção de pôster (`largura = altura * 0.675`).

> [!codigo] Como responder
> **"De onde vêm os dados do Início?"** — "Dos Controllers: `TituloController.listar()` e `HistoricoController.listarComNomes()`. A tela não tem SQL."
>
> **"Como achou o perfil mais recente?"** — "Percorro o histórico guardando o registro com a maior `dataUltimaVisualizacao` (`isAfter`)."
>
> **"E se o banco estiver fora?"** — "O `try/catch` deixa as listas vazias e a tela abre sem fileiras."

---
⬅ [[Código do front-end - Índice]] · [[Início e capas]] · [[Front-end - Capa e Icone]]
