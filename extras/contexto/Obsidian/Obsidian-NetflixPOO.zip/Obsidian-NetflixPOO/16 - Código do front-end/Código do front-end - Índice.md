---
tags: [netflix, front-end, codigo, indice]
---

# Código da Front-end · Índice (explicação de cada parte)

> [!info] O que é a versão com front-end
> **Mesma lógica da versão principal** (Model, DAO, Controller, Util e a mesma navegação), mas com a **View personalizada**: tema escuro, capas, avatares, cartões. Pasta `Versão com front-end\Netflix\src`. O que mudou está só em `view` (e em `Main`, que chama `Tema.aplicar()`).
>
> Model/DAO/Controller/Util da versão com front-end = os da versão principal (ver pastas 04 a 07). Aqui explicamos **só a View nova**.

## Mapa das classes de `view` (versão com front-end)

| Classe | Linhas | Faz | Nota |
|---|---|---|---|
| `Main` | pequena | Liga o Nimbus (`Tema.aplicar()`) e abre a `TelaConexao` dentro de `invokeLater` | [[Front-end - Nimbus, UIManager e renderers]] |
| `Tema` | 544 | Cores, fontes, botão desenhado, estilos de campo/combo/tabela/rolagem | [[Front-end - Tema]] |
| `Icone` | 62 | `enum` com ícones desenhados em código | [[Front-end - Capa e Icone]] |
| `Capa` | 117 | Pôster: imagem do disco (com cache) ou capa desenhada | [[Front-end - Capa e Icone]] |
| `PainelRolavel` | 129 | `Scrollable` + `QuebraLayout` | [[Front-end - Visao, Visoes e PainelRolavel]] |
| `Visao` | 58 | Classe abstrata + interface `Acoes` | [[Front-end - Visao, Visoes e PainelRolavel]] |
| `Visoes` | 707 | As 4 visões (Perfis, Contas, Histórico, Planos) | [[Front-end - Visao, Visoes e PainelRolavel]] |
| `BarraNavegacao` | 102 | Barra do topo (com `ItemDoMenu`) | [[BarraNavegacao]] (versão principal explica a lógica; a versão com front-end só muda o visual) |
| `Navegador` | 66 | Troca de tela com fade | [[Navegador]] · [[Timer, glass pane e fade]] |
| `TelaCrud` | 455 | Tela base do CRUD (Template Method) + layout com visão | [[Front-end - TelaCrud]] |
| `TelaPlano/Conta/Perfil/Titulo/Historico` | 60–110 | Telas filhas: campos + chamadas ao Controller + `criarVisao` | [[Telas filhas]] |
| `TelaPrincipal` | 373 | Tela **Início** (destaque + fileiras de capas) | [[Front-end - TelaPrincipal (Início)]] |
| `TelaRelatorio` | 188 | Relatório por período com "chips" | [[TelaRelatorio]] |
| `TelaConexao` | 99 | Tela de conexão estilizada | [[TelaConexao]] |

## O que a versão com front-end NÃO mudou (se o professor perguntar)
- **Nenhum SQL, DAO, Controller ou Model foi alterado** para o visual.
- As visões **leem o mesmo `DefaultTableModel`** da tabela. Trocar entre "Visual" e "Tabela" não consulta o banco.
- Os botões **Inserir / Alterar / Remover / Limpar** chamam os mesmos métodos (`inserir()`, `atualizar(id)`, `eliminar(id)`) → Controller → DAO.

## Ordem sugerida para estudar
1. [[Front-end - Tema]] → como o tema é aplicado
2. [[Front-end - Java2D e desenho]] → como se desenha um componente
3. [[Front-end - TelaCrud]] → o layout com visão
4. [[Front-end - Visao, Visoes e PainelRolavel]] → as visões
5. [[Front-end - Capa e Icone]] → imagens e ícones
6. [[Front-end - TelaPrincipal (Início)]]
7. [[Front-end - Imagens, cache e rolagem]] (resumo dos recursos extras)

---
⬅ [[00 - Painel]] · [[Fora da aula - Índice]] · [[Front-end]]
