---
tags: [netflix, codigo, view, classe]
---

# TelaRelatorio

*Seção 7.7: TelaRelatorio (nova: relatório da rotina principal)* · Pasta: [[Pacote view]]


Não herda de [[TelaCrud]] porque **não é um cadastro**: tem filtros, uma tabela e totais.

- Campos: `campoDataInicial` (padrão `01/01/2025`), `campoDataFinal` (padrão hoje), `comboPerfil` ("Todos" + perfis) e `labelResumo` (totais embaixo).
- `modelo = new DefaultTableModel(new String[]{"ID", "Início", "Perfil", "Título", "Minuto de parada", "Concluído", "Dispositivo"}, 0) {...}`: tabela só de leitura.
- `private List<HistoricoVisualizacao> resultado`: guarda o último relatório, usado pelo botão **Salvar .txt**.
- Botões: `btnGerar.addActionListener(e -> gerar());` e `btnSalvar.addActionListener(e -> salvar());`.
- No construtor, preenche o combo de perfis e já chama `gerar()` (abre mostrando o relatório). O `try/catch (RuntimeException e)` mostra o erro se o banco estiver fora do ar.
- `gerar()`: `resultado = controller.gerar(dataInicial, dataFinal, perfil);` (validação e erro de banco caem no `catch`); depois `modelo.setRowCount(0)`, um `addRow` por visualização (nomes vindos do JOIN) e `labelResumo.setText(controller.resumo(resultado))`.
- `salvar()`: `JFileChooser escolher = new JFileChooser(); escolher.setSelectedFile(new File("relatorio_visualizacoes.txt"));`; se o usuário confirmar (`APPROVE_OPTION`), chama `controller.salvarTxt(...)` e mostra a mensagem.

---
⬅ [[Telas filhas]] · [[00 - Painel]] · [[Integração Java-MySQL]] ➡
