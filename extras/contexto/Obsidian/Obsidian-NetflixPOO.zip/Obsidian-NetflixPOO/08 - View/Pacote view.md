---
tags: [netflix, codigo, view]
---

# Pacote view

*Seção 7 da documentação: Pacote view (telas Swing) e o Main*


A View só **captura dados** e **mostra resultados**. Nenhum botão tem SQL ou regra de negócio.

## Notas desta pasta

- [[Conceitos de Swing]]: Conceitos de Swing usados
- [[Main]]: Main (ponto de entrada)
- [[TelaConexao]]: TelaConexao (nova)
- [[TelaPrincipal]]: TelaPrincipal (menu)
- [[TelaCrud]]: TelaCrud (tela base, abstract)
- [[Telas filhas]]: As telas filhas (TelaPlano, TelaConta, TelaPerfil, TelaTitulo, TelaHistorico)
- [[TelaRelatorio]]: TelaRelatorio (nova: relatório da rotina principal)
- [[BarraNavegacao]]: a barra do topo, igual em todas as telas
- [[Navegador]]: troca de tela no mesmo lugar, com fade

---
⬅ [[ConexaoController]] · [[00 - Painel]] · [[Conceitos de Swing]] ➡
