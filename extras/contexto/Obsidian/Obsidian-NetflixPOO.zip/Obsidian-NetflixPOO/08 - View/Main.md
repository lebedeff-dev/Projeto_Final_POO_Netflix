---
tags: [netflix, codigo, view, classe]
---

# Main

*Seção 7.2: Main (ponto de entrada)* · Pasta: [[Pacote view]]


- `public static void main(String[] args)`: é o que o `Netflix.jar` executa (o manifesto do jar diz `Main-Class: Main`).
- `SwingUtilities.invokeLater(() -> new TelaConexao().setVisible(true));`: cria a primeira tela na *Event Dispatch Thread*, a thread que o Swing exige para mexer na interface.

---
⬅ [[Conceitos de Swing]] · [[00 - Painel]] · [[TelaConexao]] ➡
