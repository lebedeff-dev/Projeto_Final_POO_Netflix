---
tags: [netflix, view, navegacao, principal]
---

# BarraNavegacao (`view/BarraNavegacao.java`) · versão principal

*A barra do topo, igual em todas as telas.*

## O que mostra
`NETFLIX` + um botão por tela: **Início, Planos, Contas, Perfis, Títulos, Histórico** (o Relatório abre pelo botão da tela de Histórico). O botão da tela atual fica **desabilitado**. No canto direito pode entrar um componente extra (na tela Início, o botão "Restaurar dados").

## Linha a linha

| Trecho | O que faz |
|---|---|
| `extends JPanel` | A barra **é** um painel: qualquer tela a coloca com `add(barra, BorderLayout.NORTH)` |
| Construtor `BarraNavegacao(JFrame dona, String atual, Component direita)` | `dona` = janela onde está (será trocada); `atual` = nome da tela atual; `direita` = extra opcional (pode ser `null`) |
| `super(new BorderLayout())` | Painel com `BorderLayout`: esquerda (`WEST`) e direita (`EAST`) |
| `new JPanel(new FlowLayout(FlowLayout.LEFT))` | Linha de botões alinhada à esquerda |
| `esquerda.add(botao("Planos", atual, e -> Navegador.ir(dona, new TelaPlano())))` | Cada botão é **uma linha**: o `e -> ...` é uma **lambda** (o `ActionListener`) |
| `if (direita != null)` | Só cria o lado direito se alguém passou um componente |
| `private JButton botao(texto, atual, acao)` | Método auxiliar que evita repetir 7 vezes o mesmo código |
| `texto.equals(atual)` → `setEnabled(false)` | O botão da tela onde já estamos não faz nada e fica cinza |
| `else b.addActionListener(acao)` | Os outros ligam a ação |

## Onde é usada
- [[TelaCrud]] (`barraECabecalho`), [[TelaRelatorio]] e [[TelaPrincipal]] (com "Restaurar dados").
- Para o botão certo ficar desabilitado, `TelaCrud.nomeNaBarra()` converte o título "Histórico de Visualização" em "Histórico".

> [!codigo] Como responder
> **"Por que 7 botões iguais não repetem código?"** — "Criei o método `botao(...)`, que monta o botão e decide se ele fica habilitado; a barra só chama esse método."
>
> **"O que é a lambda `e -> Navegador.ir(...)`?"** — "A forma curta de escrever um `ActionListener`: 'quando clicar, faça isto'."

---
⬅ [[Pacote view]] · [[Navegador]] · [[TelaCrud]]
